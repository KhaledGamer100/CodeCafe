
import os
import logging
import asyncio
import threading
from bot import bot

class BotManager:
    def __init__(self):
        self.bot = bot
        self.bot_token = "MTM3Mzg4ODM1MjA1ODc0MDc3Ng.GDYvqk.0mG5QMBRUCeDUnhk6PhddSu3y57Ku_jHdoD-uY"
        self.loop = None
        self.bot_thread = None
        
    def start_bot(self):
        """Start the Discord bot"""
        if not self.bot_token:
            logging.warning("DISCORD_BOT_TOKEN environment variable not set! Bot will not connect to Discord.")
            return
            
        try:
            logging.info(f"Starting Discord bot with token length: {len(self.bot_token)}")
            
            # تشغيل البوت بشكل مباشر
            self.bot.run(self.bot_token, reconnect=True)
            
        except KeyboardInterrupt:
            logging.info("Bot stopped by user")
        except Exception as e:
            logging.error(f"Failed to start Discord bot: {e}")
            # Don't crash the application if bot fails to start
    
    def stop_bot(self):
        """Stop the Discord bot"""
        if self.bot and not self.bot.is_closed():
            try:
                asyncio.create_task(self.bot.close())
            except Exception as e:
                logging.error(f"Error stopping bot: {e}")
    
    def restart_bot(self):
        """Restart the Discord bot"""
        logging.info("Restarting bot...")
        self.stop_bot()
        # Wait a moment for cleanup
        threading.Timer(3.0, self.start_bot).start()
    
    def is_bot_online(self):
        """Check if bot is online"""
        return self.bot and not self.bot.is_closed() and self.bot.is_ready()
    
    def get_bot_stats(self):
        """Get bot statistics"""
        if not self.is_bot_online():
            return {
                'online': False,
                'latency': 0,
                'guild_count': 0,
                'user_count': 0,
                'uptime': '0s'
            }
        
        try:
            from datetime import datetime
            uptime = datetime.utcnow() - self.bot.start_time
            hours, remainder = divmod(int(uptime.total_seconds()), 3600)
            minutes, seconds = divmod(remainder, 60)
            uptime_str = f"{hours}h {minutes}m {seconds}s"
            
            return {
                'online': True,
                'latency': round(self.bot.latency * 1000, 2),
                'guild_count': len(self.bot.guilds),
                'user_count': sum(guild.member_count or 0 for guild in self.bot.guilds),
                'uptime': uptime_str
            }
        except Exception as e:
            logging.error(f"Error getting bot stats: {e}")
            return {
                'online': False,
                'latency': 0,
                'guild_count': 0,
                'user_count': 0,
                'uptime': '0s',
                'error': str(e)
            }
