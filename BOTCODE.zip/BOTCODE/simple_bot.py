
import asyncio
import logging
from discord_bot import bot, TOKEN

# تكوين السجلات
logging.basicConfig(level=logging.INFO)

async def main():
    try:
        await bot.start(TOKEN)
    except KeyboardInterrupt:
        await bot.close()

if __name__ == "__main__":
    asyncio.run(main())
