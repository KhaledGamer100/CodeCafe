from app import db
from datetime import datetime
from sqlalchemy import Text

class BotConfig(db.Model):
    __tablename__ = 'bot_config'

    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(100), unique=True, nullable=False)
    value = db.Column(Text, nullable=False)
    description = db.Column(Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class CommandLog(db.Model):
    __tablename__ = 'command_logs'

    id = db.Column(db.Integer, primary_key=True)
    command = db.Column(db.String(100), nullable=False)
    user_id = db.Column(db.String(100), nullable=False)
    user_name = db.Column(db.String(100), nullable=False)
    guild_id = db.Column(db.String(100), nullable=False)
    guild_name = db.Column(db.String(100), nullable=False)
    channel_id = db.Column(db.String(100), nullable=False)
    channel_name = db.Column(db.String(100), nullable=False)
    args = db.Column(Text)
    success = db.Column(db.Boolean, default=True)
    error_message = db.Column(Text)
    executed_at = db.Column(db.DateTime, default=datetime.utcnow)

class BotStatus(db.Model):
    __tablename__ = 'bot_status'

    id = db.Column(db.Integer, primary_key=True)
    is_online = db.Column(db.Boolean, default=False)
    latency = db.Column(db.Float, default=0.0)
    guild_count = db.Column(db.Integer, default=0)
    user_count = db.Column(db.Integer, default=0)
    last_updated = db.Column(db.DateTime, default=datetime.utcnow)

class Ticket(db.Model):
    __tablename__ = 'tickets'

    id = db.Column(db.Integer, primary_key=True)
    ticket_id = db.Column(db.String(100), unique=True, nullable=False)
    channel_id = db.Column(db.String(100), nullable=False)
    creator_id = db.Column(db.String(100), nullable=False)
    creator_name = db.Column(db.String(100), nullable=False)
    guild_id = db.Column(db.String(100), nullable=False)
    subject = db.Column(db.String(200), default='General Support')
    status = db.Column(db.String(20), default='open')  # open, closed, resolved
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    closed_at = db.Column(db.DateTime)

class VoiceRoom(db.Model):
    __tablename__ = 'voice_rooms'

    id = db.Column(db.Integer, primary_key=True)
    channel_id = db.Column(db.String(100), unique=True, nullable=False)
    owner_id = db.Column(db.String(100), nullable=False)
    owner_name = db.Column(db.String(100), nullable=False)
    guild_id = db.Column(db.String(100), nullable=False)
    room_name = db.Column(db.String(100), nullable=False)
    is_temporary = db.Column(db.Boolean, default=True)
    max_users = db.Column(db.Integer, default=10)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class ModerationLog(db.Model):
    __tablename__ = 'moderation_logs'

    id = db.Column(db.Integer, primary_key=True)
    action_type = db.Column(db.String(50), nullable=False)  # ban, kick, mute, warn, etc.
    target_user_id = db.Column(db.String(100), nullable=False)
    target_user_name = db.Column(db.String(100), nullable=False)
    moderator_id = db.Column(db.String(100), nullable=False)
    moderator_name = db.Column(db.String(100), nullable=False)
    guild_id = db.Column(db.String(100), nullable=False)
    reason = db.Column(Text)
    duration = db.Column(db.Integer)  # Duration in minutes for temporary actions
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    expires_at = db.Column(db.DateTime)

class UserWarning(db.Model):
    __tablename__ = 'user_warnings'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(100), nullable=False)
    user_name = db.Column(db.String(100), nullable=False)
    guild_id = db.Column(db.String(100), nullable=False)
    moderator_id = db.Column(db.String(100), nullable=False)
    moderator_name = db.Column(db.String(100), nullable=False)
    reason = db.Column(Text, nullable=False)
    warning_number = db.Column(db.Integer, default=1)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class AutoRole(db.Model):
    __tablename__ = 'auto_roles'

    id = db.Column(db.Integer, primary_key=True)
    guild_id = db.Column(db.String(100), nullable=False)
    role_id = db.Column(db.String(100), nullable=False)
    role_name = db.Column(db.String(100), nullable=False)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class WelcomeMessage(db.Model):
    __tablename__ = 'welcome_messages'

    id = db.Column(db.Integer, primary_key=True)
    guild_id = db.Column(db.String(100), unique=True, nullable=False)
    channel_id = db.Column(db.String(100), nullable=False)
    message_content = db.Column(Text, nullable=False)
    is_enabled = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class UserLevel(db.Model):
    __tablename__ = 'user_levels'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(100), nullable=False)
    user_name = db.Column(db.String(100), nullable=False)
    guild_id = db.Column(db.String(100), nullable=False)
    xp = db.Column(db.Integer, default=0)
    level = db.Column(db.Integer, default=1)
    messages_sent = db.Column(db.Integer, default=0)
    last_xp_gain = db.Column(db.DateTime, default=datetime.utcnow)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Poll(db.Model):
    __tablename__ = 'polls'

    id = db.Column(db.Integer, primary_key=True)
    poll_id = db.Column(db.String(100), unique=True, nullable=False)
    guild_id = db.Column(db.String(100), nullable=False)
    channel_id = db.Column(db.String(100), nullable=False)
    message_id = db.Column(db.String(100), nullable=False)
    creator_id = db.Column(db.String(100), nullable=False)
    question = db.Column(Text, nullable=False)
    options = db.Column(Text, nullable=False)  # JSON string
    votes = db.Column(Text, default='{}')  # JSON string of votes
    is_active = db.Column(db.Boolean, default=True)
    ends_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Giveaway(db.Model):
    __tablename__ = 'giveaways'

    id = db.Column(db.Integer, primary_key=True)
    giveaway_id = db.Column(db.String(100), unique=True, nullable=False)
    guild_id = db.Column(db.String(100), nullable=False)
    channel_id = db.Column(db.String(100), nullable=False)
    message_id = db.Column(db.String(100), nullable=False)
    creator_id = db.Column(db.String(100), nullable=False)
    prize = db.Column(db.String(200), nullable=False)
    winner_count = db.Column(db.Integer, default=1)
    participants = db.Column(Text, default='[]')  # JSON array of user IDs
    winners = db.Column(Text, default='[]')  # JSON array of winner IDs
    is_active = db.Column(db.Boolean, default=True)
    ends_at = db.Column(db.DateTime, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class ReactionRole(db.Model):
    __tablename__ = 'reaction_roles'

    id = db.Column(db.Integer, primary_key=True)
    guild_id = db.Column(db.String(100), nullable=False)
    channel_id = db.Column(db.String(100), nullable=False)
    message_id = db.Column(db.String(100), nullable=False)
    emoji = db.Column(db.String(100), nullable=False)
    role_id = db.Column(db.String(100), nullable=False)
    role_name = db.Column(db.String(100), nullable=False)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class AutoReply(db.Model):
    __tablename__ = 'auto_replies'

    id = db.Column(db.Integer, primary_key=True)
    guild_id = db.Column(db.String(100), nullable=False)
    trigger = db.Column(db.String(200), nullable=False)
    response = db.Column(Text, nullable=False)
    is_exact_match = db.Column(db.Boolean, default=False)
    is_active = db.Column(db.Boolean, default=True)
    usage_count = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class ServerStats(db.Model):
    __tablename__ = 'server_stats'

    id = db.Column(db.Integer, primary_key=True)
    guild_id = db.Column(db.String(100), nullable=False)
    date = db.Column(db.Date, nullable=False)
    member_count = db.Column(db.Integer, default=0)
    message_count = db.Column(db.Integer, default=0)
    voice_minutes = db.Column(db.Integer, default=0)
    new_members = db.Column(db.Integer, default=0)
    left_members = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class AntiSpamConfig(db.Model):
    __tablename__ = 'anti_spam_config'

    id = db.Column(db.Integer, primary_key=True)
    guild_id = db.Column(db.String(100), unique=True, nullable=False)
    is_enabled = db.Column(db.Boolean, default=True)
    max_messages = db.Column(db.Integer, default=5)
    time_window = db.Column(db.Integer, default=10)  # seconds
    mute_duration = db.Column(db.Integer, default=300)  # seconds
    delete_messages = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)