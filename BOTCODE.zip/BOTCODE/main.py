
import threading
import logging
import asyncio
from app import app, socketio, db
from bot_manager import BotManager

# تكوين السجلات
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

# إنشاء مثيل من BotManager على مستوى العامة
bot_manager = None

def run_bot():
    """تشغيل البوت في thread منفصل"""
    global bot_manager
    bot_manager = BotManager()
    bot_manager.start_bot()

def main():
    # إنشاء قاعدة البيانات
    with app.app_context():
        db.create_all()
        logging.info("تم إنشاء قاعدة البيانات بنجاح")
    
    # تشغيل البوت في thread منفصل
    bot_thread = threading.Thread(target=run_bot, daemon=True)
    bot_thread.start()
    logging.info("تم بدء تشغيل البوت")
    
    # انتظار تهيئة البوت
    import time
    time.sleep(2)
    
    # تشغيل Flask app على منفذ مختلف
    try:
        socketio.run(app, host='0.0.0.0', port=8000, debug=False, allow_unsafe_werkzeug=True)
    except Exception as e:
        logging.error(f"فشل في تشغيل Flask app على المنفذ 8000: {e}")
        # محاولة منفذ آخر
        socketio.run(app, host='0.0.0.0', port=3000, debug=False, allow_unsafe_werkzeug=True)

if __name__ == "__main__":
    main()
