import os
import logging
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_socketio import SocketIO
from sqlalchemy.orm import DeclarativeBase
from werkzeug.middleware.proxy_fix import ProxyFix

# Set up enhanced logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('bot_web.log')
    ]
)
logger = logging.getLogger(__name__)

class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)
socketio = SocketIO()

def create_app():
    """Factory function to create Flask application with proper context"""
    app = Flask(__name__)
    app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key-change-in-production")

    # Proxy configuration for production
    if os.environ.get('FLASK_ENV') == 'production':
        app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

    # Database configuration
    app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get(
        "DATABASE_URL", "sqlite:///discord_bot.db"
    )
    app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
        "pool_recycle": 300,
        "pool_pre_ping": True,
        "pool_size": 10,
        "max_overflow": 20,
    }
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

    # Initialize extensions
    db.init_app(app)
    socketio.init_app(
        app, 
        cors_allowed_origins="*",
        async_mode='gevent',
        logger=logger,
        engineio_logger=True
    )

    # Database initialization
    with app.app_context():
        try:
            from . import models  # Relative import for better structure
            db.create_all()
            logger.info("Database tables initialized successfully")
        except Exception as e:
            logger.error(f"Database initialization error: {str(e)}")

    # Import routes after app initialization
    from . import routes
    app.register_blueprint(routes.bp)

    # Register custom CLI commands
    register_cli_commands(app)

    return app

def register_cli_commands(app):
    """Register custom command-line interface commands"""
    @app.cli.command("init-db")
    def init_db():
        """Initialize the database"""
        try:
            db.create_all()
            logger.info("Database tables created successfully")
        except Exception as e:
            logger.error(f"Error initializing database: {str(e)}")

# Create the Flask application
app = create_app()

# Import Socket.IO event handlers after app creation
from . import socket_events  # Separate file for Socket.IO events

# Run the application
if __name__ == "__main__":
    # Get port from environment or default to 5000
    port = int(os.environ.get("PORT", 5000))

    # Get host from environment or default to localhost
    host = os.environ.get("HOST", "0.0.0.0")

    socketio.run(
        app, 
        host=host, 
        port=port, 
        debug=(os.environ.get('FLASK_ENV') != 'production'),
        allow_unsafe_werkzeug=True
    )                                                                                                                                                                                                            