
import discord
from discord.ext import commands, tasks
import os
import logging
import asyncio
from datetime import datetime, timedelta
import uuid
import re
import json
import random
import aiohttp

# Import database models
from app import db, socketio
from models import (CommandLog, BotStatus, Ticket, VoiceRoom, BotConfig, ModerationLog, 
                   UserWarning, AutoRole, WelcomeMessage, UserLevel, Poll, Giveaway, 
                   ReactionRole, AutoReply, ServerStats, AntiSpamConfig)

# توكن البوت
TOKEN = "MTM3Mzg4ODM1MjA1ODc0MDc3Ng.GDYvqk.0mG5QMBRUCeDUnhk6PhddSu3y57Ku_jHdoD-uY"

# Bot configuration
intents = discord.Intents.all()

class DiscordBot(commands.Bot):
    def __init__(self):
        super().__init__(
            command_prefix='+',  # تغيير البادئة إلى +
            intents=intents,
            help_command=None
        )
        self.start_time = datetime.utcnow()

    async def on_ready(self):
        logging.info(f'{self.user} has connected to Discord!')
        print(f"🤖 البوت اشتغل باسم {self.user}")
        print(f"🌐 متصل بـ {len(self.guilds)} سيرفر")
        print(f"👥 يخدم {sum(guild.member_count or 0 for guild in self.guilds)} عضو")

        # Set bot status
        activity = discord.Activity(type=discord.ActivityType.watching, name="للمساعدة +help")
        await self.change_presence(status=discord.Status.online, activity=activity)

        # Sync slash commands
        try:
            await self.tree.sync()
            print("✅ تمت مزامنة الأوامر.")
        except Exception as e:
            print(f"مشكلة في المزامنة: {e}")

        await self.update_bot_status()

        # Start background tasks
        self.update_status_task.start()

        # Emit status update to dashboard
        try:
            socketio.emit('bot_status_update', {
                'online': True,
                'latency': round(self.latency * 1000, 2),
                'guild_count': len(self.guilds),
                'user_count': sum(guild.member_count or 0 for guild in self.guilds)
            })
        except:
            pass

    @tasks.loop(minutes=5)
    async def update_status_task(self):
        """Update bot status periodically"""
        await self.update_bot_status()

    async def update_bot_status(self):
        """Update bot status in database"""
        try:
            await self.loop.run_in_executor(None, self._update_status_sync)
        except:
            pass

    def _update_status_sync(self):
        """Synchronous helper for database updates"""
        try:
            from app import app
            with app.app_context():
                status = BotStatus.query.first()
                if not status:
                    status = BotStatus()
                    db.session.add(status)

                status.is_online = True
                status.latency = round(self.latency * 1000, 2) if self.latency else 0
                status.guild_count = len(self.guilds)
                status.user_count = sum(guild.member_count or 0 for guild in self.guilds)
                status.last_updated = datetime.utcnow()

                db.session.commit()
        except:
            pass

    async def log_command(self, ctx, success=True, error_message=None):
        """Log command execution"""
        def _log_sync():
            try:
                from app import app
                with app.app_context():
                    log_entry = CommandLog(
                        command=ctx.command.name if ctx.command else 'unknown',
                        user_id=str(ctx.author.id),
                        user_name=ctx.author.display_name,
                        guild_id=str(ctx.guild.id) if ctx.guild else 'DM',
                        guild_name=ctx.guild.name if ctx.guild else 'Direct Message',
                        channel_id=str(ctx.channel.id),
                        channel_name=ctx.channel.name if hasattr(ctx.channel, 'name') else 'DM',
                        args=' '.join(ctx.message.content.split()[1:]) if ctx.message else '',
                        success=success,
                        error_message=error_message
                    )
                    db.session.add(log_entry)
                    db.session.commit()

                    # Emit to dashboard
                    socketio.emit('new_command_log', {
                        'command': log_entry.command,
                        'user': log_entry.user_name,
                        'guild': log_entry.guild_name,
                        'success': success,
                        'timestamp': log_entry.executed_at.isoformat(),
                        'error': error_message
                    })
            except:
                pass

        try:
            await self.loop.run_in_executor(None, _log_sync)
        except:
            pass

    async def close(self):
        """Clean shutdown"""
        if hasattr(self, 'update_status_task'):
            self.update_status_task.cancel()
        await super().close()

# Create bot instance
bot = DiscordBot()
tree = bot.tree

# Helper functions
def parse_amount(amount_str):
    pattern = r"^(\d+)([kmbq]?)$"
    match = re.match(pattern, amount_str.lower().strip())
    if not match:
        return None
    number = int(match.group(1))
    suffix = match.group(2)
    multipliers = {
        '': 1,
        'k': 10**3,
        'm': 10**6,
        'b': 10**9,
        'q': 10**12
    }
    return number * multipliers.get(suffix, 1)

def load_data():
    try:
        with open("points_data.json", "r", encoding="utf-8") as f:
            return json.load(f)
    except:
        return {}

def save_data(data):
    with open("points_data.json", "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

def parse_time(time_str):
    """Parse time string like '10m', '1h', '2d' and return minutes"""
    if not time_str:
        return None

    time_units = {'s': 1/60, 'm': 1, 'h': 60, 'd': 1440, 'w': 10080}
    match = re.match(r'^(\d+)([smhdw])$', time_str.lower())

    if match:
        amount, unit = match.groups()
        return int(amount) * time_units[unit]
    return None

async def log_moderation_action(action_type, target_user, moderator, guild_id, reason=None, duration=None):
    """Log moderation action to database"""
    def _log_sync():
        try:
            from app import app
            with app.app_context():
                expires_at = None
                if duration:
                    expires_at = datetime.utcnow() + timedelta(minutes=duration)

                log_entry = ModerationLog(
                    action_type=action_type,
                    target_user_id=str(target_user.id),
                    target_user_name=target_user.display_name,
                    moderator_id=str(moderator.id),
                    moderator_name=moderator.display_name,
                    guild_id=str(guild_id),
                    reason=reason,
                    duration=duration,
                    expires_at=expires_at
                )
                db.session.add(log_entry)
                db.session.commit()
        except:
            pass

    try:
        await bot.loop.run_in_executor(None, _log_sync)
    except:
        pass

# ======================== HELP COMMAND ========================

def create_help_embed(guild):
    """Create help embed"""
    server_icon = guild.icon.url if guild and guild.icon else None
    server_name = guild.name if guild else "السيرفر"

    embed = discord.Embed(
        title="🎯 مركز المساعدة الشامل",
        description="مرحبًا بك في مركز المساعدة! هنا هتلاقي كل أوامر البوت بشكل منسق وسهل الاستخدام 🧠✨",
        color=0x2ecc71
    )
    if server_icon:
        embed.set_thumbnail(url=server_icon)
    embed.set_author(name=server_name, icon_url=server_icon if server_icon else "")

    embed.add_field(
        name="🛍️ **الأوامر الرئيسية**",
        value="""
**+points @user** - لمعرفة نقاط أي شخص
**+عطيني** - لعرض عدد النقاط الخاصة بك
**+اضف_نقاط @user [المبلغ]** - لإضافة نقاط لشخص
**+خصم_نقاط @user [المبلغ]** - لخصم نقاط من شخص
**+لعبه** - للعب لعبة الروليت
**+توب** - لعرض أعلى 10 أشخاص بالنقاط
**+توب_الكل** - لعرض أعلى 50 شخص في كل السيرفرات
**+رتبتي** - عرض رتبتك في نظام المستويات
**+ترتيب** - عرض ترتيب أعلى المستويات
        """,
        inline=False
    )

    embed.add_field(
        name="ℹ️ **أوامر المعلومات**",
        value="""
**+weather [city]** - حالة الطقس
**+translate [text]** - ترجمة النص
**+avatar @user** - صورة الشخص
**+server_info** - معلومات السيرفر
**+user_info @user** - معلومات المستخدم
**+إحصائيات_السيرفر** - إحصائيات مفصلة للسيرفر
**+bot_status** - حالة البوت
        """,
        inline=False
    )

    embed.add_field(
        name="🛡️ **أوامر الإدارة**",
        value="""
**+ban @user [reason]** - حظر مستخدم
**+kick @user [reason]** - طرد مستخدم
**+mute @user [time] [reason]** - كتم مستخدم
**+unmute @user** - إلغاء كتم مستخدم
**+تحذير @user [reason]** - إعطاء تحذير لعضو
**+التحذيرات @user** - عرض تحذيرات عضو
**+إزالة_تحذير @user [#]** - إزالة تحذير
**+clear [amount]** - حذف الرسائل
**+slowmode [seconds]** - تفعيل الوضع البطيء
        """,
        inline=False
    )

    embed.add_field(
        name="🔒 **أوامر إدارة القنوات**",
        value="""
**+lock** - قفل القناة للرسائل
**+unlock** - فتح القناة
**+قفل_القناة** - قفل القناة بالكامل
**+فتح_القناة** - فتح القناة بالكامل
**+نسخ_القناة [name]** - نسخ قناة
**+role @user @role** - إعطاء/إزالة رتبة
        """,
        inline=False
    )

    embed.add_field(
        name="🎮 **أوامر الترفيه**",
        value="""
**+8ball [question]** - كرة الحظ
**+coinflip** - رمي العملة
**+dice [sides]** - رمي النرد
**+joke** - نكتة عشوائية
**+quote** - اقتباس ملهم
**+meme** - ميم عشوائي
        """,
        inline=False
    )

    embed.add_field(
        name="🎯 **أوامر التفاعل**",
        value="""
**+استطلاع [time] سؤال|خيار1|خيار2** - إنشاء استطلاع
**+create_ticket [subject]** - إنشاء تذكرة دعم
**+close_ticket** - إغلاق تذكرة دعم
        """,
        inline=False
    )

    embed.set_footer(text=f"البوت شغال من {bot.start_time.strftime('%Y-%m-%d')} | الإصدار 2.0")
    return embed

# ======================== SLASH COMMANDS ========================

@tree.command(name="help", description="عرض قائمة المساعدة الشاملة")
async def help_slash(interaction: discord.Interaction):
    embed = create_help_embed(interaction.guild)
    await interaction.response.send_message(embed=embed, ephemeral=True)

@tree.command(name="عطيني", description="عرض نقاطك")
async def points_self_slash(interaction: discord.Interaction):
    user_id = str(interaction.user.id)
    data = load_data()
    points = data.get(user_id, 0)
    
    embed = discord.Embed(
        title="💰 نقاطك",
        description=f"عندك **{points:,}** نقطة يا {interaction.user.mention}!",
        color=0xf1c40f
    )
    embed.set_thumbnail(url=interaction.user.avatar.url if interaction.user.avatar else interaction.user.default_avatar.url)
    
    await interaction.response.send_message(embed=embed, ephemeral=True)

@tree.command(name="points", description="عرض نقاط شخص معين")
async def points_user_slash(interaction: discord.Interaction, user: discord.User):
    user_id = str(user.id)
    data = load_data()
    points = data.get(user_id, 0)
    
    embed = discord.Embed(
        title="💰 النقاط",
        description=f"نقاط {user.mention} هي **{points:,}** نقطة",
        color=0x3498db
    )
    embed.set_thumbnail(url=user.avatar.url if user.avatar else user.default_avatar.url)
    
    await interaction.response.send_message(embed=embed, ephemeral=True)

@tree.command(name="اضف_نقاط", description="إضافة نقاط لشخص معين")
async def add_points_slash(interaction: discord.Interaction, user: discord.User, amount: str):
    if not interaction.user.guild_permissions.administrator:
        await interaction.response.send_message("❌ تحتاج صلاحيات إدارية لاستخدام هذا الأمر!", ephemeral=True)
        return
        
    amount_value = parse_amount(amount)
    if amount_value is None:
        await interaction.response.send_message("❌ الرجاء إدخال مبلغ صحيح مع الاختصارات مثل 100k أو 2m.", ephemeral=True)
        return
        
    data = load_data()
    user_id = str(user.id)
    current_points = data.get(user_id, 0)
    data[user_id] = current_points + amount_value
    save_data(data)
    
    embed = discord.Embed(
        title="✅ تم إضافة النقاط",
        description=f"تم إضافة **{amount_value:,}** نقطة لـ {user.mention}",
        color=0x00ff00
    )
    embed.add_field(name="النقاط الجديدة", value=f"{data[user_id]:,}", inline=True)
    embed.add_field(name="المضاف بواسطة", value=interaction.user.mention, inline=True)
    
    await interaction.response.send_message(embed=embed)

@tree.command(name="خصم_نقاط", description="خصم نقاط من شخص معين")
async def remove_points_slash(interaction: discord.Interaction, user: discord.User, amount: str):
    if not interaction.user.guild_permissions.administrator:
        await interaction.response.send_message("❌ تحتاج صلاحيات إدارية لاستخدام هذا الأمر!", ephemeral=True)
        return
        
    amount_value = parse_amount(amount)
    if amount_value is None:
        await interaction.response.send_message("❌ الرجاء إدخال مبلغ صحيح مع الاختصارات مثل 100k أو 2m.", ephemeral=True)
        return
        
    data = load_data()
    user_id = str(user.id)
    current_points = data.get(user_id, 0)
    new_points = max(current_points - amount_value, 0)
    data[user_id] = new_points
    save_data(data)
    
    embed = discord.Embed(
        title="✅ تم خصم النقاط",
        description=f"تم خصم **{amount_value:,}** نقطة من {user.mention}",
        color=0xff6b6b
    )
    embed.add_field(name="النقاط المتبقية", value=f"{new_points:,}", inline=True)
    embed.add_field(name="المخصوم بواسطة", value=interaction.user.mention, inline=True)
    
    await interaction.response.send_message(embed=embed)

@tree.command(name="لعبه", description="للعب لعبة الروليت")
async def game_rullet_slash(interaction: discord.Interaction):
    outcomes = [
        ("موت", "🔥", 0xff0000, "يا خسارة، أنت مت! تم حذف جميع نقاطك."),
        ("نجا", "🎉", 0x00ff00, "مبروك، أنت نجا! احتفظت بنقاطك."),
        ("مكافأة", "💎", 0xffd700, "واو! حصلت على مكافأة 1000 نقطة!")
    ]
    
    weights = [60, 35, 5]
    outcome, emoji, color, message = random.choices(outcomes, weights=weights)[0]
    
    data = load_data()
    user_id = str(interaction.user.id)
    current_points = data.get(user_id, 0)
    
    embed = discord.Embed(
        title=f"{emoji} نتيجة لعبة الروليت",
        description=message,
        color=color
    )
    
    if outcome == "موت":
        if user_id in data:
            data.pop(user_id)
            save_data(data)
        embed.add_field(name="النقاط المفقودة", value=f"{current_points:,}", inline=True)
    elif outcome == "مكافأة":
        data[user_id] = current_points + 1000
        save_data(data)
        embed.add_field(name="النقاط الجديدة", value=f"{data[user_id]:,}", inline=True)
    else:
        embed.add_field(name="النقاط الحالية", value=f"{current_points:,}", inline=True)
    
    embed.set_footer(text=f"لعب بواسطة {interaction.user.display_name}")
    await interaction.response.send_message(embed=embed)

@tree.command(name="توب", description="عرض أعلى 10 أشخاص بالنقاط")
async def top10_slash(interaction: discord.Interaction):
    data = load_data()
    sorted_data = sorted(data.items(), key=lambda x: x[1], reverse=True)[:10]
    
    embed = discord.Embed(
        title="🏆 أعلى 10 أشخاص بالنقاط",
        color=0xf1c40f
    )
    
    if not sorted_data:
        embed.description = "لا يوجد أشخاص بنقاط حاليًا"
    else:
        description = ""
        medals = ["🥇", "🥈", "🥉"] + ["🏅"] * 7
        
        for idx, (user_id, points) in enumerate(sorted_data):
            try:
                user = await bot.fetch_user(int(user_id))
                description += f"{medals[idx]} **{idx+1}.** {user.display_name} - **{points:,}** نقطة\n"
            except:
                description += f"{medals[idx]} **{idx+1}.** Unknown User - **{points:,}** نقطة\n"
        
        embed.description = description
    
    embed.set_footer(text=f"السيرفر: {interaction.guild.name}")
    await interaction.response.send_message(embed=embed, ephemeral=True)

@tree.command(name="توب_الكل", description="عرض أعلى 50 شخص في كل السيرفرات")
async def top50_slash(interaction: discord.Interaction):
    data = load_data()
    sorted_data = sorted(data.items(), key=lambda x: x[1], reverse=True)[:50]
    
    embed = discord.Embed(
        title="🌟 أعلى 50 شخص في النقاط عالميًا",
        color=0x3498db
    )
    
    if not sorted_data:
        embed.description = "لا يوجد أشخاص بنقاط حاليًا"
        await interaction.response.send_message(embed=embed, ephemeral=True)
        return
    
    pages = [sorted_data[i:i+10] for i in range(0, len(sorted_data), 10)]
    current_page = 0
    
    def create_embed(page_data, page_num):
        embed = discord.Embed(
            title=f"🌟 أعلى 50 شخص في النقاط عالميًا (صفحة {page_num + 1}/{len(pages)})",
            color=0x3498db
        )
        
        description = ""
        for idx, (user_id, points) in enumerate(page_data):
            global_rank = page_num * 10 + idx + 1
            try:
                user = bot.get_user(int(user_id))
                if not user:
                    user_name = f"User #{user_id[:8]}"
                else:
                    user_name = user.display_name
            except:
                user_name = f"User #{user_id[:8]}"
            
            if global_rank <= 3:
                medals = ["🥇", "🥈", "🥉"]
                description += f"{medals[global_rank-1]} **{global_rank}.** {user_name} - **{points:,}** نقطة\n"
            else:
                description += f"🏅 **{global_rank}.** {user_name} - **{points:,}** نقطة\n"
        
        embed.description = description
        embed.set_footer(text=f"إجمالي المتصدرين: {len(sorted_data)}")
        return embed
    
    embed = create_embed(pages[current_page], current_page)
    await interaction.response.send_message(embed=embed, ephemeral=True)

@tree.command(name="weather", description="معرفة حالة الطقس في مدينة")
async def weather_slash(interaction: discord.Interaction, city: str):
    await interaction.response.defer()
    
    try:
        embed = discord.Embed(
            title=f"🌤️ الطقس في {city}",
            description="ميزة الطقس قيد التطوير - ستحتاج API key من OpenWeatherMap",
            color=0x87ceeb
        )
        embed.add_field(name="الحالة", value="مشمس ☀️", inline=True)
        embed.add_field(name="درجة الحرارة", value="25°C", inline=True)
        embed.add_field(name="الرطوبة", value="60%", inline=True)
        
        await interaction.followup.send(embed=embed)
    except Exception as e:
        await interaction.followup.send(f"❌ خطأ في جلب بيانات الطقس: {str(e)}")

@tree.command(name="translate", description="ترجمة النص")
async def translate_slash(interaction: discord.Interaction, text: str, to_language: str = "ar"):
    embed = discord.Embed(
        title="🌐 الترجمة",
        description="ميزة الترجمة قيد التطوير - ستحتاج Google Translate API",
        color=0x4285f4
    )
    embed.add_field(name="النص الأصلي", value=text, inline=False)
    embed.add_field(name="الترجمة", value=f"مترجم إلى {to_language}: {text}", inline=False)
    
    await interaction.response.send_message(embed=embed, ephemeral=True)

@tree.command(name="avatar", description="عرض صورة الشخص")
async def avatar_slash(interaction: discord.Interaction, user: discord.User = None):
    target = user or interaction.user
    
    embed = discord.Embed(
        title=f"🖼️ صورة {target.display_name}",
        color=0xe74c3c
    )
    
    avatar_url = target.avatar.url if target.avatar else target.default_avatar.url
    embed.set_image(url=avatar_url)
    embed.add_field(name="رابط مباشر", value=f"[اضغط هنا]({avatar_url})", inline=True)
    
    await interaction.response.send_message(embed=embed)

@tree.command(name="server_info", description="معلومات السيرفر")
async def server_info_slash(interaction: discord.Interaction):
    guild = interaction.guild
    
    embed = discord.Embed(
        title=f"🏰 معلومات {guild.name}",
        color=0x9b59b6
    )
    
    if guild.icon:
        embed.set_thumbnail(url=guild.icon.url)
    
    embed.add_field(name="👑 المالك", value=guild.owner.mention if guild.owner else "غير معروف", inline=True)
    embed.add_field(name="👥 الأعضاء", value=f"{guild.member_count:,}", inline=True)
    embed.add_field(name="📅 تاريخ الإنشاء", value=guild.created_at.strftime("%Y-%m-%d"), inline=True)
    embed.add_field(name="📊 القنوات", value=f"📝 {len(guild.text_channels)} | 🔊 {len(guild.voice_channels)}", inline=True)
    embed.add_field(name="📜 الــرتــب", value=len(guild.roles), inline=True)
    embed.add_field(name="😀 الإيموجي", value=len(guild.emojis), inline=True)
    embed.add_field(name="🚀 البوستر", value=f"المستوى {guild.premium_tier}", inline=True)
    embed.add_field(name="🔒 مستوى الحماية", value=str(guild.verification_level), inline=True)
    
    await interaction.response.send_message(embed=embed)

@tree.command(name="user_info", description="معلومات المستخدم")
async def user_info_slash(interaction: discord.Interaction, user: discord.User = None):
    target = user or interaction.user
    member = interaction.guild.get_member(target.id) if interaction.guild else None
    
    embed = discord.Embed(
        title=f"👤 معلومات {target.display_name}",
        color=target.accent_color or 0x2ecc71
    )
    
    if target.avatar:
        embed.set_thumbnail(url=target.avatar.url)
    
    embed.add_field(name="🆔 الآيدي", value=target.id, inline=True)
    embed.add_field(name="📅 انضم لديسكورد", value=target.created_at.strftime("%Y-%m-%d"), inline=True)
    
    if member:
        embed.add_field(name="📅 انضم للسيرفر", value=member.joined_at.strftime("%Y-%m-%d") if member.joined_at else "غير معروف", inline=True)
        embed.add_field(name="📜 الــرتــب", value=f"{len(member.roles)-1} رتبة", inline=True)
        if member.premium_since:
            embed.add_field(name="🚀 بوستر منذ", value=member.premium_since.strftime("%Y-%m-%d"), inline=True)
    
    embed.add_field(name="🤖 بوت؟", value="نعم" if target.bot else "لا", inline=True)
    
    await interaction.response.send_message(embed=embed)

@tree.command(name="رتبتي", description="عرض رتبتك في نظام المستويات")
async def rank_slash(interaction: discord.Interaction):
    await interaction.response.defer()
    
    def _get_user_level():
        try:
            from app import app
            with app.app_context():
                user_level = UserLevel.query.filter_by(
                    user_id=str(interaction.user.id),
                    guild_id=str(interaction.guild.id)
                ).first()
                
                if not user_level:
                    return None
                
                # Get rank
                higher_users = UserLevel.query.filter(
                    UserLevel.guild_id == str(interaction.guild.id),
                    UserLevel.xp > user_level.xp
                ).count()
                
                rank = higher_users + 1
                
                return {
                    'level': user_level.level,
                    'xp': user_level.xp,
                    'messages': user_level.messages_sent,
                    'rank': rank
                }
        except:
            return None
    
    data = await bot.loop.run_in_executor(None, _get_user_level)
    
    if not data:
        embed = discord.Embed(
            title="📊 رتبتك",
            description="لم تبدأ بعد في كسب الخبرة! أرسل بعض الرسائل لتبدأ.",
            color=0x95a5a6
        )
    else:
        next_level_xp = data['level'] * 100
        progress = ((data['xp'] % 100) / 100) * 100
        
        embed = discord.Embed(
            title="📊 رتبتك",
            color=0x3498db
        )
        embed.set_thumbnail(url=interaction.user.avatar.url if interaction.user.avatar else interaction.user.default_avatar.url)
        embed.add_field(name="🏆 الرتبة", value=f"#{data['rank']}", inline=True)
        embed.add_field(name="⭐ المستوى", value=data['level'], inline=True)
        embed.add_field(name="💎 نقاط الخبرة", value=f"{data['xp']:,}", inline=True)
        embed.add_field(name="📝 الرسائل", value=f"{data['messages']:,}", inline=True)
        embed.add_field(name="📈 التقدم", value=f"{progress:.1f}%", inline=True)
        embed.add_field(name="🎯 المستوى التالي", value=f"{100 - (data['xp'] % 100)} XP", inline=True)
        
        # Progress bar
        filled = int(progress / 10)
        bar = "█" * filled + "░" * (10 - filled)
        embed.add_field(name="📊 شريط التقدم", value=f"`{bar}` {progress:.1f}%", inline=False)
    
    await interaction.followup.send(embed=embed)

@tree.command(name="تحذير", description="إعطاء تحذير لعضو")
async def warn_slash(interaction: discord.Interaction, member: discord.Member, reason: str = "لم يتم تحديد سبب"):
    if not interaction.user.guild_permissions.kick_members:
        await interaction.response.send_message("❌ تحتاج صلاحيات طرد الأعضاء لاستخدام هذا الأمر!", ephemeral=True)
        return
    
    if member == interaction.user:
        await interaction.response.send_message("❌ لا يمكنك تحذير نفسك!", ephemeral=True)
        return
    
    await interaction.response.defer()
    
    def _add_warning():
        try:
            from app import app
            with app.app_context():
                warning_count = UserWarning.query.filter_by(
                    user_id=str(member.id),
                    guild_id=str(interaction.guild.id),
                    is_active=True
                ).count() + 1
                
                warning = UserWarning(
                    user_id=str(member.id),
                    user_name=member.display_name,
                    guild_id=str(interaction.guild.id),
                    moderator_id=str(interaction.user.id),
                    moderator_name=interaction.user.display_name,
                    reason=reason,
                    warning_number=warning_count
                )
                db.session.add(warning)
                db.session.commit()
                
                return warning_count
        except:
            return 1
    
    warning_count = await bot.loop.run_in_executor(None, _add_warning)
    
    # Send DM to user
    try:
        embed_dm = discord.Embed(
            title="⚠️ تم تحذيرك",
            description=f"تم تحذيرك في **{interaction.guild.name}**",
            color=0xf39c12
        )
        embed_dm.add_field(name="السبب", value=reason, inline=False)
        embed_dm.add_field(name="المشرف", value=interaction.user.display_name, inline=True)
        embed_dm.add_field(name="رقم التحذير", value=f"{warning_count}", inline=True)
        embed_dm.set_footer(text="تذكر قراءة قوانين السيرفر")
        await member.send(embed=embed_dm)
    except:
        pass
    
    # Public message
    embed = discord.Embed(
        title="⚠️ تم إعطاء تحذير",
        description=f"**{member.display_name}** تم تحذيره",
        color=0xf39c12
    )
    embed.add_field(name="السبب", value=reason, inline=False)
    embed.add_field(name="المشرف", value=interaction.user.mention, inline=True)
    embed.add_field(name="رقم التحذير", value=f"{warning_count}", inline=True)
    embed.set_thumbnail(url=member.avatar.url if member.avatar else member.default_avatar.url)
    
    if warning_count >= 3:
        embed.add_field(name="⚠️ تنبيه", value="هذا العضو وصل لـ 3 تحذيرات أو أكثر!", inline=False)
    
    await interaction.followup.send(embed=embed)

@tree.command(name="ترتيب", description="عرض ترتيب أعلى المستويات")
async def leaderboard_slash(interaction: discord.Interaction, page: int = 1):
    await interaction.response.defer()
    
    def _get_leaderboard():
        try:
            from app import app
            with app.app_context():
                per_page = 10
                offset = (page - 1) * per_page
                
                users = UserLevel.query.filter_by(
                    guild_id=str(interaction.guild.id)
                ).order_by(UserLevel.xp.desc()).offset(offset).limit(per_page).all()
                
                total_count = UserLevel.query.filter_by(guild_id=str(interaction.guild.id)).count()
                total_pages = (total_count + per_page - 1) // per_page
                
                return users, total_pages, total_count
        except:
            return [], 1, 0
    
    users, total_pages, total_count = await bot.loop.run_in_executor(None, _get_leaderboard)
    
    embed = discord.Embed(
        title=f"🏆 ترتيب المستويات - صفحة {page}/{total_pages}",
        color=0xf1c40f
    )
    embed.set_footer(text=f"إجمالي الأعضاء: {total_count}")
    
    if not users:
        embed.description = "لا يوجد بيانات للعرض"
    else:
        description = ""
        medals = ["🥇", "🥈", "🥉"] + ["🏅"] * 7
        
        for idx, user in enumerate(users):
            rank = (page - 1) * 10 + idx + 1
            medal = medals[idx] if idx < 10 else "🏅"
            
            try:
                member = interaction.guild.get_member(int(user.user_id))
                name = member.display_name if member else user.user_name
            except:
                name = user.user_name
            
            description += f"{medal} **{rank}.** {name}\n"
            description += f"    ⭐ مستوى {user.level} | 💎 {user.xp:,} XP | 📝 {user.messages_sent:,} رسالة\n\n"
        
        embed.description = description
    
    await interaction.followup.send(embed=embed)

@tree.command(name="coinflip", description="رمي العملة")
async def coinflip_slash(interaction: discord.Interaction):
    result = random.choice(["صورة", "كتابة"])
    emoji = "🪙" if result == "صورة" else "📝"
    
    embed = discord.Embed(
        title=f"{emoji} رمي العملة",
        description=f"النتيجة: **{result}**",
        color=0xf39c12
    )
    await interaction.response.send_message(embed=embed)

@tree.command(name="dice", description="رمي النرد")
async def dice_slash(interaction: discord.Interaction, sides: int = 6):
    if sides < 2 or sides > 100:
        await interaction.response.send_message("❌ يجب أن يكون عدد الأوجه بين 2 و 100!", ephemeral=True)
        return
    
    result = random.randint(1, sides)
    embed = discord.Embed(
        title="🎲 رمي النرد",
        description=f"النتيجة: **{result}** من {sides}",
        color=0x9b59b6
    )
    await interaction.response.send_message(embed=embed)

# ======================== PREFIX COMMANDS ========================

@bot.event
async def on_command_error(ctx, error):
    try:
        await bot.log_command(ctx, success=False, error_message=str(error))
        
        if isinstance(error, commands.MissingPermissions):
            await ctx.send("❌ ليس لديك الصلاحيات المطلوبة لتنفيذ هذا الأمر!")
        elif isinstance(error, commands.BotMissingPermissions):
            await ctx.send("❌ البوت لا يملك الصلاحيات المطلوبة!")
        elif isinstance(error, commands.MemberNotFound):
            await ctx.send("❌ لم يتم العثور على هذا العضو!")
        elif isinstance(error, commands.CommandNotFound):
            return
        else:
            await ctx.send(f"❌ حدث خطأ: {error}")
    except:
        pass

@bot.event
async def on_command_completion(ctx):
    try:
        await bot.log_command(ctx, success=True)
    except:
        pass

# Help command
@bot.command(name='help')
async def help_command(ctx):
    embed = create_help_embed(ctx.guild)
    await ctx.send(embed=embed)

# Points commands
@bot.command(name='عطيني')
async def points_self(ctx):
    user_id = str(ctx.author.id)
    data = load_data()
    points = data.get(user_id, 0)
    
    embed = discord.Embed(
        title="💰 نقاطك",
        description=f"عندك **{points:,}** نقطة يا {ctx.author.mention}!",
        color=0xf1c40f
    )
    embed.set_thumbnail(url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
    
    await ctx.send(embed=embed)

@bot.command(name='points')
async def points_user(ctx, user: discord.User):
    user_id = str(user.id)
    data = load_data()
    points = data.get(user_id, 0)
    
    embed = discord.Embed(
        title="💰 النقاط",
        description=f"نقاط {user.mention} هي **{points:,}** نقطة",
        color=0x3498db
    )
    embed.set_thumbnail(url=user.avatar.url if user.avatar else user.default_avatar.url)
    
    await ctx.send(embed=embed)

@bot.command(name='اضف_نقاط')
@commands.has_permissions(administrator=True)
async def add_points(ctx, user: discord.User, amount: str):
    amount_value = parse_amount(amount)
    if amount_value is None:
        await ctx.send("❌ الرجاء إدخال مبلغ صحيح مع الاختصارات مثل 100k أو 2m.")
        return
        
    data = load_data()
    user_id = str(user.id)
    current_points = data.get(user_id, 0)
    data[user_id] = current_points + amount_value
    save_data(data)
    
    embed = discord.Embed(
        title="✅ تم إضافة النقاط",
        description=f"تم إضافة **{amount_value:,}** نقطة لـ {user.mention}",
        color=0x00ff00
    )
    embed.add_field(name="النقاط الجديدة", value=f"{data[user_id]:,}", inline=True)
    embed.add_field(name="المضاف بواسطة", value=ctx.author.mention, inline=True)
    
    await ctx.send(embed=embed)

@bot.command(name='خصم_نقاط')
@commands.has_permissions(administrator=True)
async def remove_points(ctx, user: discord.User, amount: str):
    amount_value = parse_amount(amount)
    if amount_value is None:
        await ctx.send("❌ الرجاء إدخال مبلغ صحيح مع الاختصارات مثل 100k أو 2m.")
        return
        
    data = load_data()
    user_id = str(user.id)
    current_points = data.get(user_id, 0)
    new_points = max(current_points - amount_value, 0)
    data[user_id] = new_points
    save_data(data)
    
    embed = discord.Embed(
        title="✅ تم خصم النقاط",
        description=f"تم خصم **{amount_value:,}** نقطة من {user.mention}",
        color=0xff6b6b
    )
    embed.add_field(name="النقاط المتبقية", value=f"{new_points:,}", inline=True)
    embed.add_field(name="المخصوم بواسطة", value=ctx.author.mention, inline=True)
    
    await ctx.send(embed=embed)

@bot.command(name='لعبه')
async def game_rullet(ctx):
    outcomes = [
        ("موت", "🔥", 0xff0000, "يا خسارة، أنت مت! تم حذف جميع نقاطك."),
        ("نجا", "🎉", 0x00ff00, "مبروك، أنت نجا! احتفظت بنقاطك."),
        ("مكافأة", "💎", 0xffd700, "واو! حصلت على مكافأة 1000 نقطة!")
    ]
    
    weights = [60, 35, 5]
    outcome, emoji, color, message = random.choices(outcomes, weights=weights)[0]
    
    data = load_data()
    user_id = str(ctx.author.id)
    current_points = data.get(user_id, 0)
    
    embed = discord.Embed(
        title=f"{emoji} نتيجة لعبة الروليت",
        description=message,
        color=color
    )
    
    if outcome == "موت":
        if user_id in data:
            data.pop(user_id)
            save_data(data)
        embed.add_field(name="النقاط المفقودة", value=f"{current_points:,}", inline=True)
    elif outcome == "مكافأة":
        data[user_id] = current_points + 1000
        save_data(data)
        embed.add_field(name="النقاط الجديدة", value=f"{data[user_id]:,}", inline=True)
    else:
        embed.add_field(name="النقاط الحالية", value=f"{current_points:,}", inline=True)
    
    embed.set_footer(text=f"لعب بواسطة {ctx.author.display_name}")
    await ctx.send(embed=embed)

@bot.command(name='توب')
async def top10(ctx):
    data = load_data()
    sorted_data = sorted(data.items(), key=lambda x: x[1], reverse=True)[:10]
    
    embed = discord.Embed(
        title="🏆 أعلى 10 أشخاص بالنقاط",
        color=0xf1c40f
    )
    
    if not sorted_data:
        embed.description = "لا يوجد أشخاص بنقاط حاليًا"
    else:
        description = ""
        medals = ["🥇", "🥈", "🥉"] + ["🏅"] * 7
        
        for idx, (user_id, points) in enumerate(sorted_data):
            try:
                user = await bot.fetch_user(int(user_id))
                description += f"{medals[idx]} **{idx+1}.** {user.display_name} - **{points:,}** نقطة\n"
            except:
                description += f"{medals[idx]} **{idx+1}.** Unknown User - **{points:,}** نقطة\n"
        
        embed.description = description
    
    embed.set_footer(text=f"السيرفر: {ctx.guild.name}")
    await ctx.send(embed=embed)

@bot.command(name='توب_الكل')
async def top50(ctx):
    data = load_data()
    sorted_data = sorted(data.items(), key=lambda x: x[1], reverse=True)[:50]
    
    embed = discord.Embed(
        title="🌟 أعلى 50 شخص في النقاط عالميًا",
        color=0x3498db
    )
    
    if not sorted_data:
        embed.description = "لا يوجد أشخاص بنقاط حاليًا"
        await ctx.send(embed=embed)
        return
    
    pages = [sorted_data[i:i+10] for i in range(0, len(sorted_data), 10)]
    current_page = 0
    
    def create_embed(page_data, page_num):
        embed = discord.Embed(
            title=f"🌟 أعلى 50 شخص في النقاط عالميًا (صفحة {page_num + 1}/{len(pages)})",
            color=0x3498db
        )
        
        description = ""
        for idx, (user_id, points) in enumerate(page_data):
            global_rank = page_num * 10 + idx + 1
            try:
                user = bot.get_user(int(user_id))
                if not user:
                    user_name = f"User #{user_id[:8]}"
                else:
                    user_name = user.display_name
            except:
                user_name = f"User #{user_id[:8]}"
            
            if global_rank <= 3:
                medals = ["🥇", "🥈", "🥉"]
                description += f"{medals[global_rank-1]} **{global_rank}.** {user_name} - **{points:,}** نقطة\n"
            else:
                description += f"🏅 **{global_rank}.** {user_name} - **{points:,}** نقطة\n"
        
        embed.description = description
        embed.set_footer(text=f"إجمالي المتصدرين: {len(sorted_data)}")
        return embed
    
    embed = create_embed(pages[current_page], current_page)
    await ctx.send(embed=embed)

# Information commands
@bot.command(name='weather')
async def weather(ctx, *, city):
    try:
        embed = discord.Embed(
            title=f"🌤️ الطقس في {city}",
            description="ميزة الطقس قيد التطوير - ستحتاج API key من OpenWeatherMap",
            color=0x87ceeb
        )
        embed.add_field(name="الحالة", value="مشمس ☀️", inline=True)
        embed.add_field(name="درجة الحرارة", value="25°C", inline=True)
        embed.add_field(name="الرطوبة", value="60%", inline=True)
        
        await ctx.send(embed=embed)
    except Exception as e:
        await ctx.send(f"❌ خطأ في جلب بيانات الطقس: {str(e)}")

@bot.command(name='translate')
async def translate_text(ctx, *, text):
    embed = discord.Embed(
        title="🌐 الترجمة",
        description="ميزة الترجمة قيد التطوير - ستحتاج Google Translate API",
        color=0x4285f4
    )
    embed.add_field(name="النص الأصلي", value=text, inline=False)
    embed.add_field(name="الترجمة", value=f"مترجم: {text}", inline=False)
    
    await ctx.send(embed=embed)

@bot.command(name='avatar')
async def avatar(ctx, user: discord.User = None):
    target = user or ctx.author
    
    embed = discord.Embed(
        title=f"🖼️ صورة {target.display_name}",
        color=0xe74c3c
    )
    
    avatar_url = target.avatar.url if target.avatar else target.default_avatar.url
    embed.set_image(url=avatar_url)
    embed.add_field(name="رابط مباشر", value=f"[اضغط هنا]({avatar_url})", inline=True)
    
    await ctx.send(embed=embed)

@bot.command(name='server_info')
async def server_info(ctx):
    guild = ctx.guild
    
    embed = discord.Embed(
        title=f"🏰 معلومات {guild.name}",
        color=0x9b59b6
    )
    
    if guild.icon:
        embed.set_thumbnail(url=guild.icon.url)
    
    embed.add_field(name="👑 المالك", value=guild.owner.mention if guild.owner else "غير معروف", inline=True)
    embed.add_field(name="👥 الأعضاء", value=f"{guild.member_count:,}", inline=True)
    embed.add_field(name="📅 تاريخ الإنشاء", value=guild.created_at.strftime("%Y-%m-%d"), inline=True)
    embed.add_field(name="📊 القنوات", value=f"📝 {len(guild.text_channels)} | 🔊 {len(guild.voice_channels)}", inline=True)
    embed.add_field(name="🎭 الأدوار", value=len(guild.roles), inline=True)
    embed.add_field(name="😀 الإيموجي", value=len(guild.emojis), inline=True)
    embed.add_field(name="🚀 البوستر", value=f"المستوى {guild.premium_tier}", inline=True)
    embed.add_field(name="🔒 مستوى الحماية", value=str(guild.verification_level), inline=True)
    
    await ctx.send(embed=embed)

@bot.command(name='user_info')
async def user_info(ctx, user: discord.User = None):
    target = user or ctx.author
    member = ctx.guild.get_member(target.id) if ctx.guild else None
    
    embed = discord.Embed(
        title=f"👤 معلومات {target.display_name}",
        color=target.accent_color or 0x2ecc71
    )
    
    if target.avatar:
        embed.set_thumbnail(url=target.avatar.url)
    
    embed.add_field(name="🆔 الآيدي", value=target.id, inline=True)
    embed.add_field(name="📅 انضم لديسكورد", value=target.created_at.strftime("%Y-%m-%d"), inline=True)
    
    if member:
        embed.add_field(name="📅 انضم للسيرفر", value=member.joined_at.strftime("%Y-%m-%d") if member.joined_at else "غير معروف", inline=True)
        embed.add_field(name="🎭 الأدوار", value=f"{len(member.roles)-1} دور", inline=True)
        if member.premium_since:
            embed.add_field(name="🚀 بوستر منذ", value=member.premium_since.strftime("%Y-%m-%d"), inline=True)
    
    embed.add_field(name="🤖 بوت؟", value="نعم" if target.bot else "لا", inline=True)
    
    await ctx.send(embed=embed)

# Moderation commands
@bot.command(name='ban')
@commands.has_permissions(ban_members=True)
async def ban_user(ctx, member: discord.Member, *, reason="لم يتم تحديد سبب"):
    if member.top_role >= ctx.author.top_role and ctx.author != ctx.guild.owner:
        await ctx.send("❌ لا يمكنك حظر شخص لديه رتبة مساوية أو أعلى منك!")
        return

    if member == ctx.author:
        await ctx.send("❌ لا يمكنك حظر نفسك!")
        return

    try:
        await log_moderation_action("ban", member, ctx.author, ctx.guild.id, reason)

        try:
            embed = discord.Embed(
                title="🔨 تم حظرك",
                description=f"تم حظرك من **{ctx.guild.name}**",
                color=0xff0000
            )
            embed.add_field(name="السبب", value=reason, inline=False)
            embed.add_field(name="المشرف", value=ctx.author.display_name, inline=True)
            embed.set_footer(text="يمكنك التواصل مع إدارة السيرفر للاستفسار")
            await member.send(embed=embed)
        except:
            pass

        await member.ban(reason=f"حُظر بواسطة {ctx.author}: {reason}")

        embed = discord.Embed(
            title="🔨 تم حظر العضو",
            description=f"**{member.display_name}** تم حظره من السيرفر",
            color=0xff0000
        )
        embed.add_field(name="السبب", value=reason, inline=False)
        embed.add_field(name="المشرف", value=ctx.author.mention, inline=True)
        embed.set_thumbnail(url=member.avatar.url if member.avatar else member.default_avatar.url)

        await ctx.send(embed=embed)

    except Exception as e:
        await ctx.send(f"❌ فشل في حظر العضو: {e}")

@bot.command(name='kick')
@commands.has_permissions(kick_members=True)
async def kick_user(ctx, member: discord.Member, *, reason="لم يتم تحديد سبب"):
    if member.top_role >= ctx.author.top_role and ctx.author != ctx.guild.owner:
        await ctx.send("❌ لا يمكنك طرد شخص لديه رتبة مساوية أو أعلى منك!")
        return

    if member == ctx.author:
        await ctx.send("❌ لا يمكنك طرد نفسك!")
        return

    try:
        await log_moderation_action("kick", member, ctx.author, ctx.guild.id, reason)

        try:
            embed = discord.Embed(
                title="👢 تم طردك",
                description=f"تم طردك من **{ctx.guild.name}**",
                color=0xff9900
            )
            embed.add_field(name="السبب", value=reason, inline=False)
            embed.add_field(name="المشرف", value=ctx.author.display_name, inline=True)
            embed.set_footer(text="يمكنك العودة للسيرفر إذا كان لديك رابط دعوة")
            await member.send(embed=embed)
        except:
            pass

        await member.kick(reason=f"طُرد بواسطة {ctx.author}: {reason}")

        embed = discord.Embed(
            title="👢 تم طرد العضو",
            description=f"**{member.display_name}** تم طرده من السيرفر",
            color=0xff9900
        )
        embed.add_field(name="السبب", value=reason, inline=False)
        embed.add_field(name="المشرف", value=ctx.author.mention, inline=True)
        embed.set_thumbnail(url=member.avatar.url if member.avatar else member.default_avatar.url)

        await ctx.send(embed=embed)

    except Exception as e:
        await ctx.send(f"❌ فشل في طرد العضو: {e}")

@bot.command(name='mute')
@commands.has_permissions(moderate_members=True)
async def mute_user(ctx, member: discord.Member, time_str: str = "60m", *, reason="لم يتم تحديد سبب"):
    if member == ctx.author:
        await ctx.send("❌ لا يمكنك كتم نفسك!")
        return

    duration = parse_time(time_str) if time_str else 60
    if not duration:
        await ctx.send("❌ صيغة الوقت غير صحيحة! استخدم مثل: 10m, 1h, 2d")
        return

    try:
        until = discord.utils.utcnow() + timedelta(minutes=duration)
        await member.timeout(until, reason=f"كُتم بواسطة {ctx.author}: {reason}")

        await log_moderation_action("mute", member, ctx.author, ctx.guild.id, reason, duration)

        embed = discord.Embed(
            title="🔇 تم كتم العضو",
            description=f"**{member.display_name}** تم كتمه",
            color=0xff6600
        )
        embed.add_field(name="المدة", value=f"{duration} دقيقة", inline=True)
        embed.add_field(name="ينتهي في", value=f"<t:{int(until.timestamp())}:R>", inline=True)
        embed.add_field(name="السبب", value=reason, inline=False)
        embed.add_field(name="المشرف", value=ctx.author.mention, inline=True)
        embed.set_thumbnail(url=member.avatar.url if member.avatar else member.default_avatar.url)

        await ctx.send(embed=embed)

    except Exception as e:
        await ctx.send(f"❌ فشل في كتم العضو: {e}")

@bot.command(name='unmute')
@commands.has_permissions(moderate_members=True)
async def unmute_user(ctx, member: discord.Member):
    try:
        await member.timeout(None, reason=f"تم إلغاء الكتم بواسطة {ctx.author}")

        embed = discord.Embed(
            title="🔊 تم إلغاء كتم العضو",
            description=f"**{member.display_name}** تم إلغاء كتمه",
            color=0x00ff00
        )
        embed.add_field(name="المشرف", value=ctx.author.mention, inline=True)
        embed.set_thumbnail(url=member.avatar.url if member.avatar else member.default_avatar.url)

        await ctx.send(embed=embed)

    except Exception as e:
        await ctx.send(f"❌ فشل في إلغاء كتم العضو: {e}")

@bot.command(name='clear')
@commands.has_permissions(manage_messages=True)
async def clear_messages(ctx, amount: int = 10):
    if amount > 100:
        await ctx.send("❌ لا يمكن حذف أكثر من 100 رسالة في المرة الواحدة!")
        return

    if amount <= 0:
        await ctx.send("❌ يجب أن يكون العدد أكبر من 0!")
        return

    try:
        deleted = await ctx.channel.purge(limit=amount + 1)

        await log_moderation_action("clear", ctx.author, ctx.author, ctx.guild.id, f"تم حذف {len(deleted)-1} رسالة")

        embed = discord.Embed(
            title="🧹 تم حذف الرسائل",
            description=f"تم حذف {len(deleted)-1} رسالة",
            color=0x00ff00
        )
        embed.add_field(name="المشرف", value=ctx.author.mention, inline=True)
        embed.add_field(name="القناة", value=ctx.channel.mention, inline=True)

        msg = await ctx.send(embed=embed)
        await asyncio.sleep(5)
        await msg.delete()

    except Exception as e:
        await ctx.send(f"❌ فشل في حذف الرسائل: {e}")

@bot.command(name='slowmode')
@commands.has_permissions(manage_channels=True)
async def slowmode(ctx, seconds: int = 0):
    if seconds < 0 or seconds > 21600:
        await ctx.send("❌ يجب أن يكون الوقت بين 0 و 21600 ثانية!")
        return
    
    try:
        await ctx.channel.edit(slowmode_delay=seconds)
        
        if seconds == 0:
            await ctx.send("✅ تم إلغاء الوضع البطيء!")
        else:
            await ctx.send(f"✅ تم تفعيل الوضع البطيء لـ {seconds} ثانية!")
    except Exception as e:
        await ctx.send(f"❌ فشل في تغيير الوضع البطيء: {e}")

@bot.command(name='lock')
@commands.has_permissions(manage_channels=True)
async def lock_channel(ctx, channel: discord.TextChannel = None):
    channel = channel or ctx.channel
    
    try:
        overwrite = channel.overwrites_for(ctx.guild.default_role)
        overwrite.send_messages = False
        await channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
        
        embed = discord.Embed(
            title="🔒 تم قفل القناة",
            description=f"تم قفل {channel.mention} بواسطة {ctx.author.mention}",
            color=0xe74c3c
        )
        await ctx.send(embed=embed)
    except Exception as e:
        await ctx.send(f"❌ فشل في قفل القناة: {e}")

@bot.command(name='unlock')
@commands.has_permissions(manage_channels=True)
async def unlock_channel(ctx, channel: discord.TextChannel = None):
    channel = channel or ctx.channel
    
    try:
        overwrite = channel.overwrites_for(ctx.guild.default_role)
        overwrite.send_messages = None
        await channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
        
        embed = discord.Embed(
            title="🔓 تم فتح القناة",
            description=f"تم فتح {channel.mention} بواسطة {ctx.author.mention}",
            color=0x2ecc71
        )
        await ctx.send(embed=embed)
    except Exception as e:
        await ctx.send(f"❌ فشل في فتح القناة: {e}")

@bot.command(name='role')
@commands.has_permissions(manage_roles=True)
async def give_role(ctx, member: discord.Member, role: discord.Role):
    try:
        if role in member.roles:
            await member.remove_roles(role)
            action = "تم إزالة"
            color = 0xe74c3c
        else:
            await member.add_roles(role)
            action = "تم إعطاء"
            color = 0x2ecc71
        
        embed = discord.Embed(
            title="🎭 تم تعديل الأدوار",
            description=f"{action} دور {role.mention} {'من' if action == 'تم إزالة' else 'لـ'} {member.mention}",
            color=color
        )
        await ctx.send(embed=embed)
    except Exception as e:
        await ctx.send(f"❌ فشل في تعديل الدور: {e}")

# Fun commands
@bot.command(name='coinflip')
async def coinflip(ctx):
    result = random.choice(["صورة", "كتابة"])
    emoji = "🪙" if result == "صورة" else "📝"
    
    embed = discord.Embed(
        title=f"{emoji} رمي العملة",
        description=f"النتيجة: **{result}**",
        color=0xf39c12
    )
    await ctx.send(embed=embed)

@bot.command(name='رتبتي')
async def my_rank(ctx):
    """عرض رتبة المستخدم في نظام المستويات"""
    def _get_user_level():
        try:
            from app import app
            with app.app_context():
                user_level = UserLevel.query.filter_by(
                    user_id=str(ctx.author.id),
                    guild_id=str(ctx.guild.id)
                ).first()
                
                if not user_level:
                    return None
                
                # Get rank
                higher_users = UserLevel.query.filter(
                    UserLevel.guild_id == str(ctx.guild.id),
                    UserLevel.xp > user_level.xp
                ).count()
                
                rank = higher_users + 1
                
                return {
                    'level': user_level.level,
                    'xp': user_level.xp,
                    'messages': user_level.messages_sent,
                    'rank': rank
                }
        except:
            return None
    
    data = await bot.loop.run_in_executor(None, _get_user_level)
    
    if not data:
        embed = discord.Embed(
            title="📊 رتبتك",
            description="لم تبدأ بعد في كسب الخبرة! أرسل بعض الرسائل لتبدأ.",
            color=0x95a5a6
        )
    else:
        next_level_xp = data['level'] * 100
        progress = ((data['xp'] % 100) / 100) * 100
        
        embed = discord.Embed(
            title="📊 رتبتك",
            color=0x3498db
        )
        embed.set_thumbnail(url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
        embed.add_field(name="🏆 الرتبة", value=f"#{data['rank']}", inline=True)
        embed.add_field(name="⭐ المستوى", value=data['level'], inline=True)
        embed.add_field(name="💎 نقاط الخبرة", value=f"{data['xp']:,}", inline=True)
        embed.add_field(name="📝 الرسائل", value=f"{data['messages']:,}", inline=True)
        embed.add_field(name="📈 التقدم", value=f"{progress:.1f}%", inline=True)
        embed.add_field(name="🎯 المستوى التالي", value=f"{100 - (data['xp'] % 100)} XP", inline=True)
        
        # Progress bar
        filled = int(progress / 10)
        bar = "█" * filled + "░" * (10 - filled)
        embed.add_field(name="📊 شريط التقدم", value=f"`{bar}` {progress:.1f}%", inline=False)
    
    await ctx.send(embed=embed)

@bot.command(name='ترتيب')
async def leaderboard(ctx, page: int = 1):
    """عرض ترتيب أعلى المستويات في السيرفر"""
    def _get_leaderboard():
        try:
            from app import app
            with app.app_context():
                per_page = 10
                offset = (page - 1) * per_page
                
                users = UserLevel.query.filter_by(
                    guild_id=str(ctx.guild.id)
                ).order_by(UserLevel.xp.desc()).offset(offset).limit(per_page).all()
                
                total_count = UserLevel.query.filter_by(guild_id=str(ctx.guild.id)).count()
                total_pages = (total_count + per_page - 1) // per_page
                
                return users, total_pages, total_count
        except:
            return [], 1, 0
    
    users, total_pages, total_count = await bot.loop.run_in_executor(None, _get_leaderboard)
    
    embed = discord.Embed(
        title=f"🏆 ترتيب المستويات - صفحة {page}/{total_pages}",
        color=0xf1c40f
    )
    embed.set_footer(text=f"إجمالي الأعضاء: {total_count}")
    
    if not users:
        embed.description = "لا يوجد بيانات للعرض"
    else:
        description = ""
        medals = ["🥇", "🥈", "🥉"] + ["🏅"] * 7
        
        for idx, user in enumerate(users):
            rank = (page - 1) * 10 + idx + 1
            medal = medals[idx] if idx < 10 else "🏅"
            
            try:
                member = ctx.guild.get_member(int(user.user_id))
                name = member.display_name if member else user.user_name
            except:
                name = user.user_name
            
            description += f"{medal} **{rank}.** {name}\n"
            description += f"    ⭐ مستوى {user.level} | 💎 {user.xp:,} XP | 📝 {user.messages_sent:,} رسالة\n\n"
        
        embed.description = description
    
    await ctx.send(embed=embed)

@bot.command(name='تحذير')
@commands.has_permissions(kick_members=True)
async def warn_user(ctx, member: discord.Member, *, reason="لم يتم تحديد سبب"):
    """إعطاء تحذير لعضو"""
    if member == ctx.author:
        await ctx.send("❌ لا يمكنك تحذير نفسك!")
        return
    
    def _add_warning():
        try:
            from app import app
            with app.app_context():
                # Count existing warnings
                warning_count = UserWarning.query.filter_by(
                    user_id=str(member.id),
                    guild_id=str(ctx.guild.id),
                    is_active=True
                ).count() + 1
                
                warning = UserWarning(
                    user_id=str(member.id),
                    user_name=member.display_name,
                    guild_id=str(ctx.guild.id),
                    moderator_id=str(ctx.author.id),
                    moderator_name=ctx.author.display_name,
                    reason=reason,
                    warning_number=warning_count
                )
                db.session.add(warning)
                db.session.commit()
                
                return warning_count
        except:
            return 1
    
    warning_count = await bot.loop.run_in_executor(None, _add_warning)
    
    # Send DM to user
    try:
        embed_dm = discord.Embed(
            title="⚠️ تم تحذيرك",
            description=f"تم تحذيرك في **{ctx.guild.name}**",
            color=0xf39c12
        )
        embed_dm.add_field(name="السبب", value=reason, inline=False)
        embed_dm.add_field(name="المشرف", value=ctx.author.display_name, inline=True)
        embed_dm.add_field(name="رقم التحذير", value=f"{warning_count}", inline=True)
        embed_dm.set_footer(text="تذكر قراءة قوانين السيرفر")
        await member.send(embed=embed_dm)
    except:
        pass
    
    # Public message
    embed = discord.Embed(
        title="⚠️ تم إعطاء تحذير",
        description=f"**{member.display_name}** تم تحذيره",
        color=0xf39c12
    )
    embed.add_field(name="السبب", value=reason, inline=False)
    embed.add_field(name="المشرف", value=ctx.author.mention, inline=True)
    embed.add_field(name="رقم التحذير", value=f"{warning_count}", inline=True)
    embed.set_thumbnail(url=member.avatar.url if member.avatar else member.default_avatar.url)
    
    if warning_count >= 3:
        embed.add_field(name="⚠️ تنبيه", value="هذا العضو وصل لـ 3 تحذيرات أو أكثر!", inline=False)
    
    await ctx.send(embed=embed)

@bot.command(name='التحذيرات')
async def view_warnings(ctx, member: discord.Member = None):
    """عرض تحذيرات عضو"""
    target = member or ctx.author
    
    def _get_warnings():
        try:
            from app import app
            with app.app_context():
                warnings = UserWarning.query.filter_by(
                    user_id=str(target.id),
                    guild_id=str(ctx.guild.id),
                    is_active=True
                ).order_by(UserWarning.created_at.desc()).all()
                
                return warnings
        except:
            return []
    
    warnings = await bot.loop.run_in_executor(None, _get_warnings)
    
    embed = discord.Embed(
        title=f"⚠️ تحذيرات {target.display_name}",
        color=0xf39c12 if warnings else 0x2ecc71
    )
    embed.set_thumbnail(url=target.avatar.url if target.avatar else target.default_avatar.url)
    
    if not warnings:
        embed.description = "✅ لا يوجد تحذيرات نشطة"
    else:
        embed.description = f"عدد التحذيرات النشطة: **{len(warnings)}**"
        
        for i, warning in enumerate(warnings[:5], 1):  # Show only last 5
            embed.add_field(
                name=f"تحذير #{warning.warning_number}",
                value=f"**السبب:** {warning.reason}\n**المشرف:** {warning.moderator_name}\n**التاريخ:** {warning.created_at.strftime('%Y-%m-%d')}",
                inline=False
            )
        
        if len(warnings) > 5:
            embed.set_footer(text=f"يتم عرض آخر 5 تحذيرات من أصل {len(warnings)}")
    
    await ctx.send(embed=embed)

@bot.command(name='إزالة_تحذير')
@commands.has_permissions(kick_members=True)
async def remove_warning(ctx, member: discord.Member, warning_number: int = None):
    """إزالة تحذير من عضو"""
    def _remove_warning():
        try:
            from app import app
            with app.app_context():
                if warning_number:
                    warning = UserWarning.query.filter_by(
                        user_id=str(member.id),
                        guild_id=str(ctx.guild.id),
                        warning_number=warning_number,
                        is_active=True
                    ).first()
                    
                    if warning:
                        warning.is_active = False
                        db.session.commit()
                        return True, warning_number
                else:
                    # Remove latest warning
                    warning = UserWarning.query.filter_by(
                        user_id=str(member.id),
                        guild_id=str(ctx.guild.id),
                        is_active=True
                    ).order_by(UserWarning.created_at.desc()).first()
                    
                    if warning:
                        warning.is_active = False
                        db.session.commit()
                        return True, warning.warning_number
                
                return False, 0
        except:
            return False, 0
    
    success, removed_number = await bot.loop.run_in_executor(None, _remove_warning)
    
    if success:
        embed = discord.Embed(
            title="✅ تم إزالة التحذير",
            description=f"تم إزالة التحذير #{removed_number} من {member.mention}",
            color=0x2ecc71
        )
        embed.add_field(name="تم بواسطة", value=ctx.author.mention, inline=True)
    else:
        embed = discord.Embed(
            title="❌ فشل في إزالة التحذير",
            description="لم يتم العثور على التحذير المطلوب",
            color=0xe74c3c
        )
    
    await ctx.send(embed=embed)

@bot.command(name='استطلاع')
async def create_poll(ctx, duration: str, *, question_and_options):
    """إنشاء استطلاع رأي"""
    try:
        # Parse duration
        duration_minutes = parse_time(duration)
        if not duration_minutes:
            await ctx.send("❌ صيغة الوقت غير صحيحة! استخدم مثل: 10m, 1h, 2d")
            return
        
        # Parse question and options
        parts = question_and_options.split('|')
        if len(parts) < 3:
            await ctx.send("❌ يجب أن يكون التنسيق: `+استطلاع 1h السؤال|الخيار1|الخيار2|...`")
            return
        
        question = parts[0].strip()
        options = [opt.strip() for opt in parts[1:] if opt.strip()]
        
        if len(options) > 10:
            await ctx.send("❌ الحد الأقصى 10 خيارات")
            return
        
        # Create embed
        embed = discord.Embed(
            title="📊 استطلاع رأي",
            description=f"**{question}**",
            color=0x3498db
        )
        
        option_text = ""
        emojis = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"]
        
        for i, option in enumerate(options):
            option_text += f"{emojis[i]} {option}\n"
        
        embed.add_field(name="الخيارات", value=option_text, inline=False)
        embed.add_field(name="المدة", value=f"{duration_minutes} دقيقة", inline=True)
        embed.add_field(name="منشئ الاستطلاع", value=ctx.author.mention, inline=True)
        
        ends_at = datetime.utcnow() + timedelta(minutes=duration_minutes)
        embed.add_field(name="ينتهي في", value=f"<t:{int(ends_at.timestamp())}:R>", inline=True)
        embed.set_footer(text="اضغط على الرموز للتصويت")
        
        message = await ctx.send(embed=embed)
        
        # Add reactions
        for i in range(len(options)):
            await message.add_reaction(emojis[i])
        
        # Save to database
        def _save_poll():
            try:
                from app import app
                with app.app_context():
                    poll_id = str(uuid.uuid4())[:8]
                    poll = Poll(
                        poll_id=poll_id,
                        guild_id=str(ctx.guild.id),
                        channel_id=str(ctx.channel.id),
                        message_id=str(message.id),
                        creator_id=str(ctx.author.id),
                        question=question,
                        options=json.dumps(options),
                        ends_at=ends_at
                    )
                    db.session.add(poll)
                    db.session.commit()
                    return poll_id
            except:
                return None
        
        poll_id = await bot.loop.run_in_executor(None, _save_poll)
        
        # Schedule poll end
        asyncio.create_task(end_poll_after_delay(message, ends_at, poll_id))
        
    except Exception as e:
        await ctx.send(f"❌ خطأ في إنشاء الاستطلاع: {e}")

async def end_poll_after_delay(message, ends_at, poll_id):
    """End poll after specified time"""
    try:
        # Wait until poll ends
        delay = (ends_at - datetime.utcnow()).total_seconds()
        if delay > 0:
            await asyncio.sleep(delay)
        
        # Get fresh message
        message = await message.channel.fetch_message(message.id)
        
        # Count votes
        results = {}
        emojis = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"]
        
        for reaction in message.reactions:
            if str(reaction.emoji) in emojis:
                # Subtract 1 for bot's reaction
                count = max(0, reaction.count - 1)
                results[str(reaction.emoji)] = count
        
        # Create results embed
        embed = discord.Embed(
            title="📊 نتائج الاستطلاع",
            color=0x2ecc71
        )
        
        # Get poll from database
        def _get_poll():
            try:
                from app import app
                with app.app_context():
                    poll = Poll.query.filter_by(poll_id=poll_id).first()
                    if poll:
                        poll.is_active = False
                        db.session.commit()
                        return json.loads(poll.options), poll.question
                    return [], ""
            except:
                return [], ""
        
        options, question = await bot.loop.run_in_executor(None, _get_poll)
        
        if question:
            embed.description = f"**{question}**"
        
        total_votes = sum(results.values())
        results_text = ""
        
        for i, option in enumerate(options):
            emoji = emojis[i]
            votes = results.get(emoji, 0)
            percentage = (votes / total_votes * 100) if total_votes > 0 else 0
            
            bar_length = int(percentage / 10)
            bar = "█" * bar_length + "░" * (10 - bar_length)
            
            results_text += f"{emoji} **{option}**\n"
            results_text += f"`{bar}` {votes} صوت ({percentage:.1f}%)\n\n"
        
        embed.add_field(name="النتائج", value=results_text, inline=False)
        embed.add_field(name="إجمالي الأصوات", value=str(total_votes), inline=True)
        embed.set_footer(text="انتهى الاستطلاع")
        
        await message.edit(embed=embed)
        await message.clear_reactions()
        
    except Exception as e:
        print(f"Error ending poll: {e}")

@bot.command(name='قفل_القناة')
@commands.has_permissions(manage_channels=True)
async def lockdown_channel(ctx, channel: discord.TextChannel = None):
    """قفل القناة بالكامل"""
    channel = channel or ctx.channel
    
    try:
        overwrite = channel.overwrites_for(ctx.guild.default_role)
        overwrite.send_messages = False
        overwrite.add_reactions = False
        overwrite.create_public_threads = False
        overwrite.create_private_threads = False
        await channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
        
        embed = discord.Embed(
            title="🔒 تم قفل القناة بالكامل",
            description=f"تم قفل {channel.mention} بواسطة {ctx.author.mention}",
            color=0xe74c3c
        )
        embed.add_field(name="القيود المطبقة", 
                       value="❌ إرسال الرسائل\n❌ إضافة التفاعلات\n❌ إنشاء المحادثات", 
                       inline=False)
        await ctx.send(embed=embed)
    except Exception as e:
        await ctx.send(f"❌ فشل في قفل القناة: {e}")

@bot.command(name='فتح_القناة')
@commands.has_permissions(manage_channels=True)
async def unlock_channel(ctx, channel: discord.TextChannel = None):
    """فتح القناة بالكامل"""
    channel = channel or ctx.channel
    
    try:
        overwrite = channel.overwrites_for(ctx.guild.default_role)
        overwrite.send_messages = None
        overwrite.add_reactions = None
        overwrite.create_public_threads = None
        overwrite.create_private_threads = None
        await channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
        
        embed = discord.Embed(
            title="🔓 تم فتح القناة",
            description=f"تم فتح {channel.mention} بواسطة {ctx.author.mention}",
            color=0x2ecc71
        )
        embed.add_field(name="تم رفع القيود", 
                       value="✅ إرسال الرسائل\n✅ إضافة التفاعلات\n✅ إنشاء المحادثات", 
                       inline=False)
        await ctx.send(embed=embed)
    except Exception as e:
        await ctx.send(f"❌ فشل في فتح القناة: {e}")

@bot.command(name='نسخ_القناة')
@commands.has_permissions(manage_channels=True)
async def clone_channel(ctx, channel: discord.TextChannel = None, *, new_name=None):
    """نسخ قناة"""
    channel = channel or ctx.channel
    new_name = new_name or f"{channel.name}-copy"
    
    try:
        cloned = await channel.clone(name=new_name, reason=f"Channel cloned by {ctx.author}")
        
        embed = discord.Embed(
            title="📋 تم نسخ القناة",
            description=f"تم نسخ {channel.mention} إلى {cloned.mention}",
            color=0x3498db
        )
        embed.add_field(name="تم بواسطة", value=ctx.author.mention, inline=True)
        await ctx.send(embed=embed)
    except Exception as e:
        await ctx.send(f"❌ فشل في نسخ القناة: {e}")

@bot.command(name='إحصائيات_السيرفر')
async def detailed_server_stats(ctx):
    """إحصائيات مفصلة للسيرفر"""
    guild = ctx.guild
    
    # Count members by status
    online = sum(1 for m in guild.members if m.status == discord.Status.online)
    idle = sum(1 for m in guild.members if m.status == discord.Status.idle)
    dnd = sum(1 for m in guild.members if m.status == discord.Status.dnd)
    offline = sum(1 for m in guild.members if m.status == discord.Status.offline)
    
    # Count bots
    bots = sum(1 for m in guild.members if m.bot)
    humans = guild.member_count - bots
    
    # Channel stats
    text_channels = len(guild.text_channels)
    voice_channels = len(guild.voice_channels)
    categories = len(guild.categories)
    
    # Role stats
    roles = len(guild.roles)
    
    # Emoji stats
    static_emojis = sum(1 for e in guild.emojis if not e.animated)
    animated_emojis = sum(1 for e in guild.emojis if e.animated)
    
    embed = discord.Embed(
        title=f"📊 إحصائيات {guild.name} المفصلة",
        color=0x3498db
    )
    
    if guild.icon:
        embed.set_thumbnail(url=guild.icon.url)
    
    # Basic info
    embed.add_field(name="👑 المالك", value=guild.owner.mention if guild.owner else "غير معروف", inline=True)
    embed.add_field(name="🆔 معرف السيرفر", value=guild.id, inline=True)
    embed.add_field(name="📅 تاريخ الإنشاء", value=guild.created_at.strftime("%Y-%m-%d"), inline=True)
    
    # Member stats
    embed.add_field(name="👥 إجمالي الأعضاء", value=f"{guild.member_count:,}", inline=True)
    embed.add_field(name="👤 البشر", value=f"{humans:,}", inline=True)
    embed.add_field(name="🤖 البوتات", value=f"{bots:,}", inline=True)
    
    # Status stats
    status_text = f"🟢 متصل: {online}\n🟡 غائب: {idle}\n🔴 مشغول: {dnd}\n⚫ غير متصل: {offline}"
    embed.add_field(name="📊 حالة الأعضاء", value=status_text, inline=True)
    
    # Channel stats
    channel_text = f"📝 نصية: {text_channels}\n🔊 صوتية: {voice_channels}\n📁 فئات: {categories}"
    embed.add_field(name="📊 القنوات", value=channel_text, inline=True)
    
    # Other stats
    embed.add_field(name="🎭 الأدوار", value=roles, inline=True)
    embed.add_field(name="😀 إيموجي ثابت", value=static_emojis, inline=True)
    embed.add_field(name="🎉 إيموجي متحرك", value=animated_emojis, inline=True)
    embed.add_field(name="🚀 مستوى البوست", value=f"المستوى {guild.premium_tier}", inline=True)
    embed.add_field(name="💎 عدد البوسترز", value=guild.premium_subscription_count or 0, inline=True)
    embed.add_field(name="🔒 مستوى التحقق", value=str(guild.verification_level), inline=True)
    
    # Features
    features = []
    if guild.features:
        feature_map = {
            'COMMUNITY': 'مجتمع',
            'NEWS': 'أخبار',
            'VERIFIED': 'موثق',
            'PARTNERED': 'شريك',
            'VANITY_URL': 'رابط مخصص',
            'BANNER': 'بانر',
            'ANIMATED_ICON': 'أيقونة متحركة'
        }
        features = [feature_map.get(f, f) for f in guild.features[:5]]
    
    if features:
        embed.add_field(name="✨ الميزات الخاصة", value="\n".join(features), inline=False)
    
    embed.set_footer(text=f"تم الطلب بواسطة {ctx.author.display_name}")
    
    await ctx.send(embed=embed)

@bot.command(name='dice')
async def dice(ctx, sides: int = 6):
    if sides < 2 or sides > 100:
        await ctx.send("❌ يجب أن يكون عدد الأوجه بين 2 و 100!")
        return
    
    result = random.randint(1, sides)
    embed = discord.Embed(
        title="🎲 رمي النرد",
        description=f"النتيجة: **{result}** من {sides}",
        color=0x9b59b6
    )
    await ctx.send(embed=embed)

@bot.command(name='joke')
async def joke(ctx):
    jokes = [
        "لماذا لا يثق المبرمجون في السلالم؟ لأنها دائماً مليئة بالـ Bugs! 🐛",
        "ما هو الفرق بين القط والفاصلة؟ القط له مخالب في نهاية الكفوف والفاصلة لها توقف في نهاية الجملة! 😸",
        "لماذا لا يمكن للدراجة أن تقف بمفردها؟ لأنها متعبة جداً! 🚲",
        "ما هو اللون المفضل للإنترنت؟ الأزرق... لأنه مليء بالـ Links! 🔗",
        "لماذا ذهب الكمبيوتر إلى الطبيب؟ لأنه كان يعاني من فيروس! 💻"
    ]
    
    joke = random.choice(jokes)
    embed = discord.Embed(
        title="😂 نكتة اليوم",
        description=joke,
        color=0xf1c40f
    )
    await ctx.send(embed=embed)

@bot.command(name='quote')
async def quote(ctx):
    quotes = [
        "النجاح ليس نهائياً، والفشل ليس قاتلاً، إنما الشجاعة للاستمرار هي التي تهم. - ونستون تشرشل",
        "الطريقة الوحيدة للقيام بعمل عظيم هي أن تحب ما تفعله. - ستيف جوبز",
        "لا تدع ما لا تستطيع فعله يتدخل فيما تستطيع فعله. - جون وودن",
        "النجاح هو الانتقال من فشل إلى فشل دون فقدان الحماس. - ونستون تشرشل",
        "إن لم تبن أحلامك، فسيوظفك شخص آخر لبناء أحلامه. - دهيرو باتيل"
    ]
    
    quote = random.choice(quotes)
    embed = discord.Embed(
        title="💭 اقتباس ملهم",
        description=quote,
        color=0x3498db
    )
    await ctx.send(embed=embed)

@bot.command(name='meme')
async def meme(ctx):
    embed = discord.Embed(
        title="😂 ميم عشوائي",
        description="ميزة الميمز قيد التطوير - ستحتاج API للحصول على ميمز عشوائية",
        color=0xe67e22
    )
    embed.set_footer(text="قريباً ستكون هناك ميمز حقيقية!")
    await ctx.send(embed=embed)

@bot.command(name='8ball')
async def eight_ball(ctx, *, question):
    responses = [
        "🎱 هذا مؤكد", "🎱 بلا شك", "🎱 نعم بالتأكيد",
        "🎱 يمكنك الاعتماد على ذلك", "🎱 كما أرى، نعم", "🎱 على الأرجح",
        "🎱 المؤشرات جيدة", "🎱 نعم", "🎱 العلامات تشير إلى نعم",
        "🎱 الجواب غامض، حاول مرة أخرى", "🎱 اسأل مرة أخرى لاحقاً", "🎱 من الأفضل عدم إخبارك الآن",
        "🎱 لا يمكن التنبؤ الآن", "🎱 ركز واسأل مرة أخرى",
        "🎱 لا تعتمد على ذلك", "🎱 جوابي هو لا", "🎱 مصادري تقول لا",
        "🎱 المؤشرات ليست جيدة", "🎱 مشكوك فيه جداً"
    ]

    response = random.choice(responses)

    embed = discord.Embed(
        title="🎱 كرة الحظ السحرية",
        color=0x000000
    )
    embed.add_field(name="❓ السؤال", value=question, inline=False)
    embed.add_field(name="✨ الجواب", value=response, inline=False)
    embed.set_footer(text=f"سأل بواسطة {ctx.author.display_name}")

    await ctx.send(embed=embed)

# Bot status and utilities
@bot.command(name='bot_status')
async def bot_status_cmd(ctx):
    uptime = datetime.utcnow() - bot.start_time
    hours, remainder = divmod(int(uptime.total_seconds()), 3600)
    minutes, seconds = divmod(remainder, 60)
    
    embed = discord.Embed(title="🤖 حالة البوت", color=0x00ff00)
    embed.add_field(name="📡 البينغ", value=f"{round(bot.latency * 1000, 2)}ms", inline=True)
    embed.add_field(name="🏰 السيرفرات", value=f"{len(bot.guilds):,}", inline=True)
    embed.add_field(name="👥 المستخدمين", value=f"{sum(guild.member_count or 0 for guild in bot.guilds):,}", inline=True)
    embed.add_field(name="⚡ الأوامر", value=f"{len(bot.commands)}", inline=True)
    embed.add_field(name="⏰ مدة التشغيل", value=f"{hours}س {minutes}د {seconds}ث", inline=True)
    embed.add_field(name="🐍 إصدار Python", value="3.11", inline=True)
    embed.set_footer(text=f"البوت بدأ في {bot.start_time.strftime('%Y-%m-%d %H:%M:%S')} UTC")

    await ctx.send(embed=embed)

# Support tickets
@bot.command(name='create_ticket')
async def create_ticket(ctx, *, subject="دعم عام"):
    try:
        guild = ctx.guild
        ticket_id = str(uuid.uuid4())[:8]

        category = discord.utils.get(guild.categories, name="تذاكر الدعم")
        if not category:
            category = await guild.create_category("تذاكر الدعم")

        overwrites = {
            guild.default_role: discord.PermissionOverwrite(read_messages=False),
            ctx.author: discord.PermissionOverwrite(read_messages=True, send_messages=True),
            guild.me: discord.PermissionOverwrite(read_messages=True, send_messages=True)
        }

        staff_role = discord.utils.get(guild.roles, name="Staff") or discord.utils.get(guild.roles, name="المشرفين")
        if staff_role:
            overwrites[staff_role] = discord.PermissionOverwrite(read_messages=True, send_messages=True)

        channel = await guild.create_text_channel(
            f"ticket-{ticket_id}",
            category=category,
            overwrites=overwrites
        )

        def _save_ticket():
            try:
                from app import app
                with app.app_context():
                    ticket = Ticket(
                        ticket_id=ticket_id,
                        channel_id=str(channel.id),
                        creator_id=str(ctx.author.id),
                        creator_name=ctx.author.display_name,
                        guild_id=str(guild.id),
                        subject=subject
                    )
                    db.session.add(ticket)
                    db.session.commit()
            except:
                pass

        await bot.loop.run_in_executor(None, _save_ticket)

        embed = discord.Embed(
            title="🎫 تم إنشاء تذكرة دعم",
            description=f"**الموضوع:** {subject}\n**رقم التذكرة:** {ticket_id}",
            color=0x00ff00
        )
        embed.add_field(name="تم الإنشاء بواسطة", value=ctx.author.mention, inline=True)
        embed.add_field(name="الحالة", value="مفتوحة", inline=True)
        embed.add_field(name="تعليمات", value="سيقوم فريق الدعم بالرد عليك قريباً.\nلإغلاق التذكرة استخدم `+close_ticket`", inline=False)
        embed.set_footer(text="نشكرك لتواصلك معنا!")

        await channel.send(f"{ctx.author.mention} مرحباً بك!", embed=embed)
        await ctx.send(f"✅ تم إنشاء تذكرة الدعم: {channel.mention}")

    except Exception as e:
        await ctx.send(f"❌ فشل في إنشاء تذكرة الدعم: {e}")

@bot.command(name='close_ticket')
@commands.has_permissions(manage_channels=True)
async def close_ticket(ctx):
    if not ctx.channel.name.startswith('ticket-'):
        await ctx.send("❌ يمكن استخدام هذا الأمر فقط في قنوات التذاكر.")
        return

    try:
        def _close_ticket():
            try:
                from app import app
                with app.app_context():
                    ticket = Ticket.query.filter_by(channel_id=str(ctx.channel.id)).first()
                    if ticket:
                        ticket.status = 'closed'
                        ticket.closed_at = datetime.utcnow()
                        db.session.commit()
            except:
                pass

        await bot.loop.run_in_executor(None, _close_ticket)

        embed = discord.Embed(
            title="🔒 تم إغلاق التذكرة",
            description="تم إغلاق هذه التذكرة. سيتم حذف القناة خلال 10 ثوان.",
            color=0xff0000
        )
        embed.add_field(name="تم الإغلاق بواسطة", value=ctx.author.mention, inline=True)
        embed.set_footer(text="شكراً لاستخدام نظام الدعم!")
        
        await ctx.send(embed=embed)

        await asyncio.sleep(10)
        await ctx.channel.delete(reason=f"تذكرة مغلقة بواسطة {ctx.author}")

    except Exception as e:
        await ctx.send(f"❌ فشل في إغلاق التذكرة: {e}")

# ======================== EVENT HANDLERS ========================

@bot.event
async def on_member_join(member):
    try:
        def _get_welcome_settings():
            try:
                from app import app
                with app.app_context():
                    welcome = WelcomeMessage.query.filter_by(
                        guild_id=str(member.guild.id),
                        is_enabled=True
                    ).first()

                    autorole = AutoRole.query.filter_by(
                        guild_id=str(member.guild.id),
                        is_active=True
                    ).first()

                    return welcome, autorole
            except:
                return None, None

        welcome, autorole = await bot.loop.run_in_executor(None, _get_welcome_settings)

        if welcome:
            channel = member.guild.get_channel(int(welcome.channel_id))
            if channel:
                message = welcome.message_content.replace("{user}", member.mention).replace("{server}", member.guild.name)

                embed = discord.Embed(
                    title="🎉 مرحباً!",
                    description=message,
                    color=0x00d4ff
                )
                embed.set_thumbnail(url=member.avatar.url if member.avatar else member.default_avatar.url)
                embed.set_footer(text=f"العضو رقم {member.guild.member_count}")

                await channel.send(embed=embed)

        if autorole:
            role = member.guild.get_role(int(autorole.role_id))
            if role:
                try:
                    await member.add_roles(role, reason="Auto-role assignment")
                except discord.Forbidden:
                    pass

    except Exception as e:
        logging.error(f"Error in on_member_join: {e}")

@bot.event
async def on_message(message):
    if message.author.bot:
        return

    await bot.process_commands(message)

    def _handle_xp():
        try:
            from app import app
            with app.app_context():
                user_level = UserLevel.query.filter_by(
                    user_id=str(message.author.id),
                    guild_id=str(message.guild.id)
                ).first()

                now = datetime.utcnow()

                if not user_level:
                    user_level = UserLevel(
                        user_id=str(message.author.id),
                        user_name=message.author.display_name,
                        guild_id=str(message.guild.id)
                    )
                    db.session.add(user_level)

                if (now - user_level.last_xp_gain).total_seconds() >= 60:
                    xp_gain = random.randint(15, 25)
                    user_level.xp += xp_gain
                    user_level.messages_sent += 1
                    user_level.last_xp_gain = now

                    old_level = user_level.level
                    new_level = user_level.xp // 100 + 1

                    if new_level > old_level:
                        user_level.level = new_level
                        db.session.commit()
                        return True, new_level

                    db.session.commit()

                return False, 0
        except:
            return False, 0

    try:
        level_up, new_level = await bot.loop.run_in_executor(None, _handle_xp)

        if level_up:
            embed = discord.Embed(
                title="🎉 ترقية في المستوى!",
                description=f"**{message.author.display_name}** وصل للمستوى **{new_level}**!",
                color=0xffd700
            )
            embed.set_thumbnail(url=message.author.avatar.url if message.author.avatar else message.author.default_avatar.url)

            await message.channel.send(embed=embed, delete_after=10)

    except Exception as e:
        logging.error(f"Error in XP system: {e}")

if __name__ == "__main__":
    try:
        bot.run(TOKEN)
    except Exception as e:
        print(f"فشل في تشغيل البوت: {e}")
