from flask import render_template, request, jsonify, redirect, url_for
from flask_socketio import emit
from app import app, db, socketio
from models import BotStatus, CommandLog, Ticket, VoiceRoom, BotConfig
from datetime import datetime, timedelta
import json

@app.route('/')
def dashboard():
    """Main dashboard page"""
    # Get bot status
    bot_status = BotStatus.query.first()
    if not bot_status:
        bot_status = BotStatus(is_online=False, latency=0, guild_count=0, user_count=0)

    # Get recent command logs
    recent_logs = CommandLog.query.order_by(CommandLog.executed_at.desc()).limit(10).all()

    # Get open tickets
    open_tickets = Ticket.query.filter_by(status='open').count()

    # Get active voice rooms
    active_voice_rooms = VoiceRoom.query.count()

    return render_template('dashboard.html', 
                         bot_status=bot_status,
                         recent_logs=recent_logs,
                         open_tickets=open_tickets,
                         active_voice_rooms=active_voice_rooms)

@app.route('/logs')
def logs():
    """Command logs page"""
    page = request.args.get('page', 1, type=int)
    per_page = 50

    logs = CommandLog.query.order_by(CommandLog.executed_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )

    return render_template('logs.html', logs=logs)

@app.route('/config')
def config():
    """Configuration page"""
    configs = BotConfig.query.all()
    config_dict = {config.key: config.value for config in configs}
    return render_template('config.html', configs=config_dict)

@app.route('/api/config', methods=['POST'])
def update_config():
    """Update bot configuration"""
    try:
        data = request.get_json()

        for key, value in data.items():
            config = BotConfig.query.filter_by(key=key).first()
            if config:
                config.value = str(value)
                config.updated_at = datetime.utcnow()
            else:
                config = BotConfig(key=key, value=str(value))
                db.session.add(config)

        db.session.commit()

        socketio.emit('config_updated', {'message': 'Configuration updated successfully'})
        return jsonify({'status': 'success', 'message': 'Configuration updated'})

    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/bot/restart', methods=['POST'])
def restart_bot():
    """Restart the Discord bot"""
    try:
        from main import bot_manager
        bot_manager.restart_bot()
        socketio.emit('bot_restart', {'message': 'Bot is restarting...'})
        return jsonify({'status': 'success', 'message': 'Bot restart initiated'})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/bot/status')
def bot_status_api():
    """Get bot status via API"""
    try:
        from main import bot_manager
        stats = bot_manager.get_bot_stats()
        return jsonify(stats)
    except Exception as e:
        return jsonify({'online': False, 'error': str(e)}), 500

@app.route('/api/tickets')
def get_tickets():
    """Get tickets data for API"""
    tickets = Ticket.query.order_by(Ticket.created_at.desc()).all()

    tickets_data = []
    for ticket in tickets:
        tickets_data.append({
            'id': ticket.ticket_id,
            'subject': ticket.subject,
            'creator': ticket.creator_name,
            'status': ticket.status,
            'created_at': ticket.created_at.isoformat(),
            'closed_at': ticket.closed_at.isoformat() if ticket.closed_at else None
        })

    return jsonify(tickets_data)

@app.route('/api/voice_rooms')
def get_voice_rooms():
    """Get voice rooms data for API"""
    voice_rooms = VoiceRoom.query.order_by(VoiceRoom.created_at.desc()).all()

    rooms_data = []
    for room in voice_rooms:
        rooms_data.append({
            'id': room.channel_id,
            'name': room.room_name,
            'owner': room.owner_name,
            'max_users': room.max_users,
            'is_temporary': room.is_temporary,
            'created_at': room.created_at.isoformat()
        })

    return jsonify(rooms_data)

@app.route('/api/stats')
def get_stats():
    """Get dashboard statistics"""
    # Commands in last 24 hours
    yesterday = datetime.utcnow() - timedelta(days=1)
    recent_commands = CommandLog.query.filter(CommandLog.executed_at >= yesterday).count()

    # Success rate
    total_commands = CommandLog.query.count()
    successful_commands = CommandLog.query.filter_by(success=True).count()
    success_rate = (successful_commands / total_commands * 100) if total_commands > 0 else 0

    # Most used commands
    from sqlalchemy import func
    popular_commands = db.session.query(
        CommandLog.command,
        func.count(CommandLog.id).label('count')
    ).group_by(CommandLog.command).order_by(func.count(CommandLog.id).desc()).limit(5).all()

    return jsonify({
        'recent_commands': recent_commands,
        'success_rate': round(success_rate, 2),
        'popular_commands': [{'command': cmd, 'count': count} for cmd, count in popular_commands]
    })

# SocketIO events
@socketio.on('connect')
def handle_connect():
    """Handle client connection"""
    try:
        from main import bot_manager
        stats = bot_manager.get_bot_stats()
        emit('bot_status_update', stats)
    except Exception as e:
        emit('bot_status_update', {'online': False, 'error': str(e)})

@socketio.on('disconnect')
def handle_disconnect():
    """Handle client disconnection"""
    pass

@socketio.on('request_status_update')
def handle_status_request():
    """Handle status update request"""
    try:
        from main import bot_manager
        stats = bot_manager.get_bot_stats()
        emit('bot_status_update', stats)
    except Exception as e:
        emit('bot_status_update', {'online': False, 'error': str(e)})