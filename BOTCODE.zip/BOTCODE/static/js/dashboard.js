// Dashboard JavaScript functionality
class DashboardManager {
    constructor() {
        this.socket = null;
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 5;
        this.reconnectDelay = 1000;
        
        this.initializeSocket();
        this.setupEventListeners();
    }
    
    initializeSocket() {
        try {
            this.socket = io();
            this.setupSocketEvents();
        } catch (error) {
            console.error('Failed to initialize socket:', error);
            this.updateConnectionStatus(false);
        }
    }
    
    setupSocketEvents() {
        this.socket.on('connect', () => {
            console.log('Connected to server');
            this.reconnectAttempts = 0;
            this.updateConnectionStatus(true);
        });
        
        this.socket.on('disconnect', () => {
            console.log('Disconnected from server');
            this.updateConnectionStatus(false);
            this.attemptReconnect();
        });
        
        this.socket.on('connect_error', (error) => {
            console.error('Connection error:', error);
            this.updateConnectionStatus(false);
        });
        
        this.socket.on('bot_status_update', (data) => {
            this.updateBotStatus(data);
        });
        
        this.socket.on('new_command_log', (data) => {
            this.handleNewCommandLog(data);
        });
        
        this.socket.on('bot_restart', (data) => {
            this.showNotification(data.message, 'warning');
        });
        
        this.socket.on('config_updated', (data) => {
            this.showNotification('Configuration updated', 'info');
        });
    }
    
    setupEventListeners() {
        // Refresh page visibility
        document.addEventListener('visibilitychange', () => {
            if (!document.hidden && this.socket && !this.socket.connected) {
                this.socket.connect();
            }
        });
        
        // Periodic status requests
        setInterval(() => {
            if (this.socket && this.socket.connected) {
                this.socket.emit('request_status_update');
            }
        }, 30000); // Every 30 seconds
    }
    
    attemptReconnect() {
        if (this.reconnectAttempts < this.maxReconnectAttempts) {
            this.reconnectAttempts++;
            console.log(`Reconnection attempt ${this.reconnectAttempts}/${this.maxReconnectAttempts}`);
            
            setTimeout(() => {
                if (this.socket) {
                    this.socket.connect();
                }
            }, this.reconnectDelay * this.reconnectAttempts);
        }
    }
    
    updateConnectionStatus(connected) {
        const statusBadge = document.getElementById('bot-status-badge');
        const statusText = document.getElementById('status-text');
        
        if (statusBadge && statusText) {
            if (connected) {
                statusBadge.className = 'badge bg-success me-2';
                statusText.textContent = 'Connected';
            } else {
                statusBadge.className = 'badge bg-danger me-2';
                statusText.textContent = 'Disconnected';
            }
        }
    }
    
    updateBotStatus(data) {
        // Update status indicator
        const statusIndicator = document.getElementById('status-indicator');
        const onlineStatus = document.getElementById('bot-online-status');
        const latency = document.getElementById('bot-latency');
        const guilds = document.getElementById('bot-guilds');
        const users = document.getElementById('bot-users');
        
        if (statusIndicator) {
            const dot = statusIndicator.querySelector('.status-dot');
            if (dot) {
                dot.className = `status-dot ${data.online ? 'bg-success' : 'bg-danger'}`;
            }
        }
        
        if (onlineStatus) {
            onlineStatus.textContent = data.online ? 'Online' : 'Offline';
        }
        
        if (latency) {
            latency.textContent = `${data.latency}ms`;
        }
        
        if (guilds) {
            guilds.textContent = data.guild_count;
        }
        
        if (users) {
            users.textContent = data.user_count;
        }
        
        // Update navbar status
        this.updateConnectionStatus(data.online);
    }
    
    handleNewCommandLog(data) {
        console.log('New command log:', data);
        
        // Update recent logs table if visible
        const recentLogsTable = document.getElementById('recent-logs-table');
        if (recentLogsTable) {
            this.addLogToTable(recentLogsTable, data);
        }
        
        // Show notification
        const message = `Command ${data.command} executed by ${data.user}`;
        this.showNotification(message, data.success ? 'success' : 'danger');
    }
    
    addLogToTable(table, logData) {
        const newRow = document.createElement('tr');
        const timestamp = new Date(logData.timestamp).toLocaleTimeString();
        
        newRow.innerHTML = `
            <td><code>${logData.command}</code></td>
            <td>${logData.user}</td>
            <td>${logData.guild}</td>
            <td>
                <span class="badge bg-${logData.success ? 'success' : 'danger'}">
                    ${logData.success ? 'Success' : 'Failed'}
                </span>
            </td>
            <td><small class="text-muted">${timestamp}</small></td>
        `;
        
        // Add to top of table
        table.insertBefore(newRow, table.firstChild);
        
        // Keep only last 10 rows
        const rows = table.querySelectorAll('tr');
        if (rows.length > 10) {
            rows[rows.length - 1].remove();
        }
    }
    
    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
        notification.style.cssText = 'top: 20px; right: 20px; z-index: 1060; min-width: 300px;';
        
        notification.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        document.body.appendChild(notification);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (notification.parentNode) {
                const bsAlert = new bootstrap.Alert(notification);
                bsAlert.close();
            }
        }, 5000);
    }
    
    // Public methods for external use
    requestStatusUpdate() {
        if (this.socket && this.socket.connected) {
            this.socket.emit('request_status_update');
        }
    }
    
    getSocket() {
        return this.socket;
    }
}

// Initialize dashboard manager
const dashboardManager = new DashboardManager();

// Make socket available globally for other scripts
window.socket = dashboardManager.getSocket();

// Utility functions
function formatTimestamp(timestamp) {
    return new Date(timestamp).toLocaleString();
}

function formatDuration(seconds) {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    if (hours > 0) {
        return `${hours}h ${minutes}m ${secs}s`;
    } else if (minutes > 0) {
        return `${minutes}m ${secs}s`;
    } else {
        return `${secs}s`;
    }
}

// Export for use in other scripts
window.DashboardManager = DashboardManager;
window.dashboardManager = dashboardManager;
// Dashboard JavaScript - Enhanced Version
class DashboardManager {
    constructor() {
        this.socket = null;
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 5;
        this.reconnectDelay = 1000;
        this.charts = {};
        this.init();
    }

    init() {
        this.initSocket();
        this.initEventListeners();
        this.initAnimations();
        this.loadStats();
        this.initAutoRefresh();
    }

    initSocket() {
        try {
            this.socket = io();
            
            this.socket.on('connect', () => {
                console.log('Connected to server');
                this.updateConnectionStatus(true);
                this.reconnectAttempts = 0;
                this.socket.emit('request_status_update');
            });

            this.socket.on('disconnect', () => {
                console.log('Disconnected from server');
                this.updateConnectionStatus(false);
                this.attemptReconnect();
            });

            this.socket.on('bot_status_update', (data) => {
                this.updateBotStatus(data);
            });

            this.socket.on('new_command_log', (data) => {
                this.addNewLogEntry(data);
            });

            this.socket.on('config_updated', (data) => {
                this.showNotification('تم تحديث الإعدادات بنجاح!', 'success');
            });

            this.socket.on('bot_restart', (data) => {
                this.showNotification('يتم إعادة تشغيل البوت...', 'info');
            });

        } catch (error) {
            console.error('Socket connection error:', error);
            this.updateConnectionStatus(false);
        }
    }

    attemptReconnect() {
        if (this.reconnectAttempts < this.maxReconnectAttempts) {
            this.reconnectAttempts++;
            console.log(`Reconnection attempt ${this.reconnectAttempts}/${this.maxReconnectAttempts}`);
            
            setTimeout(() => {
                if (this.socket) {
                    this.socket.connect();
                }
            }, this.reconnectDelay * this.reconnectAttempts);
        } else {
            console.log('Max reconnection attempts reached');
            this.showNotification('فقدان الاتصال بالخادم', 'error');
        }
    }

    updateConnectionStatus(connected) {
        const statusIndicator = document.querySelector('.connection-status');
        if (statusIndicator) {
            statusIndicator.className = `connection-status status-${connected ? 'online' : 'offline'}`;
            statusIndicator.title = connected ? 'متصل' : 'غير متصل';
        }
    }

    updateBotStatus(data) {
        // Update status indicator
        const statusElement = document.getElementById('bot-status');
        if (statusElement) {
            statusElement.className = `status-indicator status-${data.online ? 'online' : 'offline'}`;
        }

        // Update metrics
        this.updateMetric('latency', data.latency || 0, 'ms');
        this.updateMetric('guild-count', data.guild_count || 0);
        this.updateMetric('user-count', data.user_count || 0);

        // Update uptime if available
        if (data.uptime) {
            this.updateMetric('uptime', data.uptime);
        }

        // Update status text
        const statusText = document.getElementById('status-text');
        if (statusText) {
            statusText.textContent = data.online ? 'متصل' : 'غير متصل';
            statusText.className = `badge ${data.online ? 'bg-success' : 'bg-danger'}`;
        }
    }

    updateMetric(id, value, suffix = '') {
        const element = document.getElementById(id);
        if (element) {
            // Animate number change
            this.animateNumber(element, value, suffix);
        }
    }

    animateNumber(element, targetValue, suffix = '') {
        const currentValue = parseInt(element.textContent.replace(/[^0-9]/g, '')) || 0;
        const difference = targetValue - currentValue;
        const duration = 1000; // 1 second
        const steps = 60;
        const stepValue = difference / steps;
        const stepDuration = duration / steps;

        let currentStep = 0;

        const timer = setInterval(() => {
            currentStep++;
            const newValue = Math.round(currentValue + (stepValue * currentStep));
            
            if (typeof targetValue === 'string') {
                element.textContent = targetValue;
            } else {
                element.textContent = newValue.toLocaleString() + suffix;
            }

            if (currentStep >= steps) {
                clearInterval(timer);
                if (typeof targetValue === 'string') {
                    element.textContent = targetValue;
                } else {
                    element.textContent = targetValue.toLocaleString() + suffix;
                }
            }
        }, stepDuration);
    }

    addNewLogEntry(data) {
        const logsContainer = document.querySelector('.recent-logs');
        if (!logsContainer) return;

        const logEntry = document.createElement('div');
        logEntry.className = `log-entry log-${data.success ? 'success' : 'error'} fade-in`;
        
        logEntry.innerHTML = `
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <strong>${data.command}</strong> بواسطة ${data.user}
                    <small class="text-muted d-block">${data.guild}</small>
                </div>
                <div class="text-end">
                    <span class="badge ${data.success ? 'bg-success' : 'bg-danger'}">
                        ${data.success ? 'نجح' : 'فشل'}
                    </span>
                    <small class="text-muted d-block">${new Date(data.timestamp).toLocaleTimeString('ar-SA')}</small>
                </div>
            </div>
            ${data.error ? `<small class="text-danger mt-1 d-block">${data.error}</small>` : ''}
        `;

        // Add to top of logs
        logsContainer.insertBefore(logEntry, logsContainer.firstChild);

        // Remove old entries if too many
        const logEntries = logsContainer.querySelectorAll('.log-entry');
        if (logEntries.length > 10) {
            logEntries[logEntries.length - 1].remove();
        }
    }

    initEventListeners() {
        // Restart bot button
        const restartBtn = document.getElementById('restart-bot-btn');
        if (restartBtn) {
            restartBtn.addEventListener('click', () => this.restartBot());
        }

        // Refresh button
        const refreshBtn = document.getElementById('refresh-btn');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => this.refreshData());
        }

        // Theme toggle
        const themeToggle = document.getElementById('theme-toggle');
        if (themeToggle) {
            themeToggle.addEventListener('click', () => this.toggleTheme());
        }
    }

    initAnimations() {
        // Add entrance animations to cards
        const cards = document.querySelectorAll('.card');
        cards.forEach((card, index) => {
            card.style.animationDelay = `${index * 0.1}s`;
            card.classList.add('fade-in');
        });
    }

    loadStats() {
        fetch('/api/stats')
            .then(response => response.json())
            .then(data => {
                this.updatePopularCommands(data.popular_commands || []);
                this.updateMetric('recent-commands', data.recent_commands || 0);
                this.updateSuccessRate(data.success_rate || 0);
            })
            .catch(error => {
                console.error('Error loading stats:', error);
            });
    }

    updatePopularCommands(commands) {
        const container = document.getElementById('popular-commands');
        if (!container) return;

        container.innerHTML = '';
        
        if (commands.length === 0) {
            container.innerHTML = '<p class="text-muted text-center">لا توجد أوامر بعد</p>';
            return;
        }

        commands.forEach((cmd, index) => {
            const cmdElement = document.createElement('div');
            cmdElement.className = 'popular-command-item slide-in-left';
            cmdElement.style.animationDelay = `${index * 0.1}s`;
            
            cmdElement.innerHTML = `
                <div class="d-flex justify-content-between align-items-center p-2 rounded mb-2" style="background: rgba(88, 101, 242, 0.1)">
                    <span class="fw-bold">${cmd.command}</span>
                    <span class="badge bg-primary">${cmd.count}</span>
                </div>
            `;
            
            container.appendChild(cmdElement);
        });
    }

    updateSuccessRate(rate) {
        const element = document.getElementById('success-rate');
        if (element) {
            this.animateNumber(element, rate, '%');
            
            // Update color based on rate
            if (rate >= 90) {
                element.className = 'metric-value text-success';
            } else if (rate >= 70) {
                element.className = 'metric-value text-warning';
            } else {
                element.className = 'metric-value text-danger';
            }
        }
    }

    initAutoRefresh() {
        // Auto-refresh every 30 seconds
        setInterval(() => {
            this.loadStats();
            if (this.socket && this.socket.connected) {
                this.socket.emit('request_status_update');
            }
        }, 30000);
    }

    restartBot() {
        if (!confirm('هل أنت متأكد من إعادة تشغيل البوت؟')) {
            return;
        }

        const btn = document.getElementById('restart-bot-btn');
        const originalText = btn.innerHTML;
        
        btn.innerHTML = '<span class="loading-spinner"></span> جاري إعادة التشغيل...';
        btn.disabled = true;

        fetch('/api/bot/restart', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                this.showNotification('تم طلب إعادة تشغيل البوت', 'success');
            } else {
                this.showNotification('خطأ في إعادة تشغيل البوت: ' + data.message, 'error');
            }
        })
        .catch(error => {
            console.error('Error restarting bot:', error);
            this.showNotification('خطأ في الاتصال', 'error');
        })
        .finally(() => {
            setTimeout(() => {
                btn.innerHTML = originalText;
                btn.disabled = false;
            }, 3000);
        });
    }

    refreshData() {
        const btn = document.getElementById('refresh-btn');
        const originalText = btn.innerHTML;
        
        btn.innerHTML = '<span class="loading-spinner"></span>';
        btn.disabled = true;

        Promise.all([
            this.loadStats(),
            this.socket ? this.socket.emit('request_status_update') : Promise.resolve()
        ])
        .finally(() => {
            setTimeout(() => {
                btn.innerHTML = originalText;
                btn.disabled = false;
                this.showNotification('تم تحديث البيانات', 'success');
            }, 1000);
        });
    }

    toggleTheme() {
        const body = document.body;
        const isDark = body.getAttribute('data-bs-theme') === 'dark';
        
        body.setAttribute('data-bs-theme', isDark ? 'light' : 'dark');
        localStorage.setItem('theme', isDark ? 'light' : 'dark');
        
        this.showNotification(`تم التبديل إلى الوضع ${isDark ? 'المضيء' : 'المظلم'}`, 'info');
    }

    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `alert alert-${type === 'error' ? 'danger' : type} alert-dismissible fade show notification-popup`;
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            min-width: 300px;
            animation: slideInRight 0.3s ease-out;
        `;
        
        notification.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;

        document.body.appendChild(notification);

        // Auto remove after 5 seconds
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 5000);
    }
}

// Initialize dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new DashboardManager();
});

// Global functions for button clicks
function restartBot() {
    if (window.dashboardManager) {
        window.dashboardManager.restartBot();
    }
}

function refreshData() {
    if (window.dashboardManager) {
        window.dashboardManager.refreshData();
    }
}
